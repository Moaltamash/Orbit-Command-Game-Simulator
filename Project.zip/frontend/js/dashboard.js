/* ============================================================
 *  ORBIT COMMAND — dashboard.js
 *  Resource management, Chart.js visualisations, constraint
 *  checking, launch-vehicle & orbit selection.
 * ============================================================ */

// ─── Chart instances (module-level) ────────────────────────
let massChart = null;
let powerChart = null;
let budgetChart = null;

// ─── Resource Calculation ──────────────────────────────────

/**
 * Recalculate all spacecraft resources from the current AppState,
 * update dashboard displays, bars, charts, and run constraint checks.
 */
function recalculateResources() {
    const state = window.AppState;
    if (!state) return;

    let totalMass = 0;
    let powerGeneration = 0;
    let powerConsumption = 0;
    let totalCost = 0;
    let dataRate = 0;
    let commCapacity = 0;

    // ── Components ──
    const compList = state.componentsList || [];
    const selectedComps = state.spacecraft.components || [];
    selectedComps.forEach((compName) => {
        const comp = compList.find((c) => c.name === compName);
        if (!comp) return;
        totalMass += comp.mass || 0;
        powerGeneration += comp.power_generation || 0;
        powerConsumption += comp.power_consumption || 0;
        totalCost += comp.cost || 0;
        commCapacity += comp.comm_capacity || 0;
    });

    // ── Instruments ──
    const instrList = state.instrumentsList || [];
    const selectedInstr = state.spacecraft.instruments || [];
    selectedInstr.forEach((instrName) => {
        const instr = instrList.find((i) => i.name === instrName);
        if (!instr) return;
        totalMass += instr.mass || 0;
        powerConsumption += instr.power_consumption || 0;
        totalCost += instr.cost || 0;
        dataRate += instr.data_rate || 0;
    });

    // ── Launch vehicle cost ──
    const vehicleList = state.launchVehicles || [];
    const selectedVehicle = vehicleList.find((v) => v.name === state.launchVehicle);
    if (selectedVehicle) {
        totalCost += selectedVehicle.cost || 0;
    }

    // ── Update AppState ──
    state.resources.totalMass = totalMass;
    state.resources.availablePower = powerGeneration - powerConsumption;
    state.resources.totalCost = totalCost;
    state.resources.dataRate = dataRate;
    state.resources.commCapacity = commCapacity;

    // Persist
    if (typeof window.saveStateToLocalStorage === 'function') {
        window.saveStateToLocalStorage();
    }

    // Update DOM
    updateResourceDisplays();
    updateResourceBars();
    updateCharts();

    // Run constraints
    const warnings = checkConstraints();
    renderConstraintWarnings(warnings);

    return state.resources;
}

window.recalculateResources = recalculateResources;

// ─── Resource Displays ─────────────────────────────────────

function updateResourceDisplays() {
    const r = window.AppState.resources;
    const mission = window.AppState.selectedMission;
    const budget = window.AppState.missionBudget || 500;
    const remaining = Math.max(0, budget - r.totalCost);

    setText('dash-mission-name', mission?.name || 'Orbital Mission');
    setText('dash-mission-type', mission?.key || mission?.id || 'Exploration');
    setText('dash-budget-remaining', `$${Math.round(remaining)}M`);

    setText('stat-total-mass', window.formatMass ? window.formatMass(r.totalMass) : `${Math.round(r.totalMass)} kg`);
    setText('stat-avail-power', window.formatPower ? window.formatPower(r.availablePower) : `${Math.round(r.availablePower)} W`);
    setText('stat-mission-budget', `$${Math.round(budget)}M`);
    setText('stat-data-rate', `${Math.round(r.dataRate)} Mbps`);

    setText('display-total-mass', window.formatMass ? window.formatMass(r.totalMass) : `${r.totalMass} kg`);
    setText('display-available-power', window.formatPower ? window.formatPower(r.availablePower) : `${r.availablePower} W`);
    setText('display-total-cost', window.formatCurrency ? window.formatCurrency(r.totalCost) : `$${r.totalCost}M`);
    setText('display-data-rate', `${r.dataRate} Mbps`);
    setText('display-comm-capacity', `${r.commCapacity} Mbps`);
    setText('display-budget-remaining', `$${remaining}M`);
}

function setText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
}

// ─── Resource Bars ─────────────────────────────────────────

/**
 * Update progress bar widths and colours.
 * Green < 60 %, yellow 60-85 %, red > 85 %.
 */
function updateResourceBars() {
    const state = window.AppState;
    const vehicle = (state.launchVehicles || []).find((v) => v.name === state.launchVehicle);
    const maxMass = vehicle ? vehicle.payload_capacity : 5000;
    const maxBudget = state.missionBudget || 500;

    // Sum generation for power ratio
    let totalGen = 0;
    (state.spacecraft.components || []).forEach((name) => {
        const c = (state.componentsList || []).find((x) => x.name === name);
        if (c) totalGen += c.power_generation || 0;
    });
    const maxPower = totalGen || 1;

    const powerUsed = totalGen - state.resources.availablePower; // consumption
    const maxComm = state.resources.commCapacity || 1;

    setBar('bar-mass', state.resources.totalMass, maxMass);
    setBar('bar-power', powerUsed, maxPower);
    setBar('bar-budget', state.resources.totalCost, maxBudget);
    setBar('bar-data', state.resources.dataRate, maxComm);
}

function setBar(id, value, max) {
    const bar = document.getElementById(id);
    if (!bar) return;
    const pct = max > 0 ? Math.min((value / max) * 100, 100) : 0;
    bar.style.width = `${pct}%`;
    bar.classList.remove('bar-green', 'bar-yellow', 'bar-red');
    if (pct < 60) bar.classList.add('bar-green');
    else if (pct < 85) bar.classList.add('bar-yellow');
    else bar.classList.add('bar-red');
    // Label
    const label = bar.querySelector('.bar-label') || bar;
    if (label) label.setAttribute('data-value', `${Math.round(pct)}%`);
}

// ─── Chart.js Visualisations ───────────────────────────────

function getChartDefaults() {
    return {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                labels: { color: '#c0c8d8', font: { size: 12 } },
            },
        },
    };
}

/**
 * Initialise the three dashboard charts.
 * Destroys existing instances first to avoid canvas reuse errors.
 */
function initDashboardCharts() {
    if (typeof Chart === 'undefined') {
        console.warn('[Dashboard] Chart.js not loaded; skipping charts.');
        return;
    }

    // Destroy old instances
    if (massChart) { massChart.destroy(); massChart = null; }
    if (powerChart) { powerChart.destroy(); powerChart = null; }
    if (budgetChart) { budgetChart.destroy(); budgetChart = null; }

    // 1. Mass breakdown (doughnut)
    const massCtx = getCtx('chart-mass-breakdown');
    if (massCtx) {
        massChart = new Chart(massCtx, {
            type: 'doughnut',
            data: {
                labels: ['Components', 'Instruments', 'Propulsion'],
                datasets: [{
                    data: [0, 0, 0],
                    backgroundColor: ['#4a6cf7', '#f7c948', '#e74c6f'],
                    borderWidth: 0,
                }],
            },
            options: {
                ...getChartDefaults(),
                cutout: '65%',
            },
        });
    }

    // 2. Power budget (bar)
    const powerCtx = getCtx('chart-power-budget');
    if (powerCtx) {
        powerChart = new Chart(powerCtx, {
            type: 'bar',
            data: {
                labels: [],
                datasets: [
                    {
                        label: 'Generation (W)',
                        data: [],
                        backgroundColor: '#22c55e',
                    },
                    {
                        label: 'Consumption (W)',
                        data: [],
                        backgroundColor: '#e74c6f',
                    },
                ],
            },
            options: {
                ...getChartDefaults(),
                scales: {
                    x: { ticks: { color: '#8892a4', font: { size: 10 } }, grid: { color: 'rgba(255,255,255,0.05)' } },
                    y: { ticks: { color: '#8892a4' }, grid: { color: 'rgba(255,255,255,0.05)' }, beginAtZero: true },
                },
            },
        });
    }

    // 3. Budget allocation (doughnut)
    const budgetCtx = getCtx('chart-budget-allocation');
    if (budgetCtx) {
        budgetChart = new Chart(budgetCtx, {
            type: 'doughnut',
            data: {
                labels: ['Components', 'Instruments', 'Launch Vehicle'],
                datasets: [{
                    data: [0, 0, 0],
                    backgroundColor: ['#4a6cf7', '#f7c948', '#22c55e'],
                    borderWidth: 0,
                }],
            },
            options: {
                ...getChartDefaults(),
                cutout: '65%',
            },
        });
    }

    updateCharts();
}

function getCtx(id) {
    const map = {
        'chart-mass-breakdown': 'mass-chart-canvas',
        'chart-power-budget': 'power-chart-canvas',
        'chart-budget-allocation': 'budget-chart-canvas',
    };
    const el = document.getElementById(id) || document.getElementById(map[id]);
    return el && el.getContext ? el.getContext('2d') : null;
}

/**
 * Refresh chart data from current AppState.
 */
function updateCharts() {
    const state = window.AppState;
    if (!state) return;

    const compList = state.componentsList || [];
    const instrList = state.instrumentsList || [];

    // ── Mass breakdown ──
    let compMass = 0, instrMass = 0, propMass = 0;
    (state.spacecraft.components || []).forEach((name) => {
        const c = compList.find((x) => x.name === name);
        if (!c) return;
        if (name.toLowerCase().includes('propulsion')) {
            propMass += c.mass || 0;
        } else {
            compMass += c.mass || 0;
        }
    });
    (state.spacecraft.instruments || []).forEach((name) => {
        const i = instrList.find((x) => x.name === name);
        if (i) instrMass += i.mass || 0;
    });

    if (massChart) {
        massChart.data.datasets[0].data = [compMass, instrMass, propMass];
        massChart.update();
    }

    // ── Power budget per component ──
    if (powerChart) {
        const labels = [];
        const genData = [];
        const conData = [];
        (state.spacecraft.components || []).forEach((name) => {
            const c = compList.find((x) => x.name === name);
            if (!c) return;
            labels.push(shortenLabel(name));
            genData.push(c.power_generation || 0);
            conData.push(c.power_consumption || 0);
        });
        (state.spacecraft.instruments || []).forEach((name) => {
            const i = instrList.find((x) => x.name === name);
            if (!i) return;
            labels.push(shortenLabel(name));
            genData.push(0);
            conData.push(i.power_consumption || 0);
        });
        powerChart.data.labels = labels;
        powerChart.data.datasets[0].data = genData;
        powerChart.data.datasets[1].data = conData;
        powerChart.update();
    }

    // ── Budget allocation ──
    if (budgetChart) {
        let compCost = 0, instrCost = 0, vehicleCost = 0;
        (state.spacecraft.components || []).forEach((name) => {
            const c = compList.find((x) => x.name === name);
            if (c) compCost += c.cost || 0;
        });
        (state.spacecraft.instruments || []).forEach((name) => {
            const i = instrList.find((x) => x.name === name);
            if (i) instrCost += i.cost || 0;
        });
        const vehicle = (state.launchVehicles || []).find((v) => v.name === state.launchVehicle);
        if (vehicle) vehicleCost = vehicle.cost || 0;

        budgetChart.data.datasets[0].data = [compCost, instrCost, vehicleCost];
        budgetChart.update();
    }
}

function shortenLabel(name) {
    if (name.length <= 14) return name;
    return name.substring(0, 12) + '…';
}

window.updateDashboardCharts = updateCharts;

// ─── Constraint Checking ───────────────────────────────────

/**
 * Check all mission constraints. Returns array of {type, msg}.
 */
function checkConstraints() {
    const state = window.AppState;
    const warnings = [];

    const vehicleList = state.launchVehicles || [];
    const vehicle = vehicleList.find((v) => v.name === state.launchVehicle);

    // Mass vs payload capacity
    if (vehicle && state.resources.totalMass > vehicle.payload_capacity) {
        warnings.push({
            type: 'error',
            msg: `Spacecraft mass (${window.formatMass(state.resources.totalMass)}) exceeds launch vehicle capacity (${window.formatMass(vehicle.payload_capacity)})`,
        });
    }

    // Power balance
    if (state.resources.availablePower < 0) {
        warnings.push({
            type: 'error',
            msg: `Power consumption exceeds generation by ${window.formatPower(Math.abs(state.resources.availablePower))}`,
        });
    }

    // Budget
    if (state.resources.totalCost > state.missionBudget && state.missionBudget > 0) {
        warnings.push({
            type: 'error',
            msg: `Total cost (${window.formatCurrency(state.resources.totalCost)}) exceeds mission budget (${window.formatCurrency(state.missionBudget)})`,
        });
    }

    // Data vs comm
    if (state.resources.dataRate > state.resources.commCapacity && state.resources.commCapacity > 0) {
        warnings.push({
            type: 'warning',
            msg: `Data rate (${state.resources.dataRate} Mbps) exceeds communication capacity (${state.resources.commCapacity} Mbps)`,
        });
    }

    // No launch vehicle selected
    if (!state.launchVehicle) {
        warnings.push({
            type: 'warning',
            msg: 'No launch vehicle selected',
        });
    }

    // No orbit selected
    if (!state.orbit) {
        warnings.push({
            type: 'warning',
            msg: 'No orbit selected',
        });
    }

    // No components at all
    if (state.spacecraft.components.length === 0) {
        warnings.push({
            type: 'warning',
            msg: 'No spacecraft components selected',
        });
    }

    // Required components for mission type
    if (state.selectedMission && state.selectedMission.required_components) {
        const required = state.selectedMission.required_components;
        required.forEach((req) => {
            const has = state.spacecraft.components.some((c) => c.toLowerCase().includes(req.toLowerCase()));
            if (!has) {
                warnings.push({
                    type: 'error',
                    msg: `Mission requires: ${req}`,
                });
            }
        });
    }

    return warnings;
}

window.checkConstraints = checkConstraints;

function renderConstraintWarnings(warnings) {
    const container = document.getElementById('warnings-list') || document.getElementById('constraint-warnings');
    if (!container) return;

    if (!warnings || warnings.length === 0) {
        container.innerHTML = '<p class="warning-placeholder" style="color:var(--success);font-weight:600;">✅ All constraints satisfied. Spacecraft is flight-ready.</p>';
        toggleLaunchButton(true);
        updateCompatibilityStatus(true, 'Configuration verified. All systems nominal.');
        return;
    }

    const hasErrors = warnings.some((w) => w.type === 'error');
    toggleLaunchButton(!hasErrors);

    container.innerHTML = warnings.map((w) => `
        <div class="warning-item ${w.type}">
            <span class="warning-icon">${w.type === 'error' ? '🚫' : '⚠️'}</span>
            <span class="warning-msg">${w.msg}</span>
        </div>
    `).join('');

    updateCompatibilityStatus(!hasErrors, hasErrors ? 'Incompatible: Resolve engineering constraints above before launch.' : 'Warnings noted: Mission is GO for launch.');
}

function updateCompatibilityStatus(isOk, message) {
    const el = document.getElementById('compat-status');
    if (el) {
        el.innerHTML = `
            <span class="compat-icon">${isOk ? '✅' : '❌'}</span>
            <span class="compat-text" style="color:${isOk ? 'var(--success)' : 'var(--danger)'};">${message}</span>
        `;
    }
}

function toggleLaunchButton(enabled) {
    const btn = document.getElementById('btn-initiate-simulation') || document.getElementById('btn-launch-simulation');
    if (!btn) return;
    btn.disabled = !enabled;
    btn.classList.toggle('btn-disabled', !enabled);
}

// ─── Launch Vehicle Selection ──────────────────────────────

function renderLaunchVehicles() {
    const container = document.querySelector('.launch-vehicle-grid') || document.getElementById('launch-vehicles-grid');
    if (!container) return;

    const vehicles = window.AppState.launchVehicles || [];
    if (vehicles.length === 0) {
        container.innerHTML = '<p class="loading-text">Loading launch vehicles…</p>';
        return;
    }

    container.innerHTML = vehicles.map((v) => `
        <div class="launch-card glass-card ${window.AppState.launchVehicle === v.name ? 'selected' : ''}"
             data-vehicle="${v.name}">
            <div class="launch-card-header">
                <span class="launch-icon">🚀</span>
                <span class="launch-name" style="font-weight:700;color:#fff;">${v.name}</span>
            </div>
            <p class="vehicle-desc" style="font-size:0.85rem;color:var(--text-secondary);margin:8px 0;">${v.description || ''}</p>
            <div class="launch-stats" style="display:flex;gap:15px;margin-bottom:8px;font-size:0.85rem;">
                <div><strong>Payload:</strong> ${window.formatMass(v.payload_capacity || 0)}</div>
                <div><strong>Cost:</strong> ${window.formatCurrency(v.cost || 0)}</div>
            </div>
            <div class="launch-orbits">
                ${(v.compatible_orbits || []).map(orb => `<span class="launch-orbit-tag">${orb}</span>`).join('')}
            </div>
            <button class="btn btn-outline btn-block select-vehicle-btn" style="margin-top:10px;">Select Vehicle</button>
        </div>
    `).join('');

    // Click handlers
    container.querySelectorAll('.launch-card').forEach((card) => {
        card.addEventListener('click', () => {
            container.querySelectorAll('.launch-card').forEach((c) => c.classList.remove('selected'));
            card.classList.add('selected');
            window.AppState.launchVehicle = card.dataset.vehicle;
            recalculateResources();
            renderOrbits(); // Update orbit compatibility
            if (typeof window.showNotification === 'function') {
                window.showNotification(`Launch vehicle selected: ${card.dataset.vehicle}`, 'success');
            }
        });
    });
}

// ─── Orbit Selection ───────────────────────────────────────

function renderOrbits() {
    const container = document.querySelector('.orbit-grid') || document.getElementById('orbits-grid');
    if (!container) return;

    const orbits = window.AppState.orbits || [];
    if (orbits.length === 0) {
        container.innerHTML = '<p class="loading-text">Loading orbits…</p>';
        return;
    }

    // Determine compatible orbits based on selected vehicle
    const vehicleList = window.AppState.launchVehicles || [];
    const vehicle = vehicleList.find((v) => v.name === window.AppState.launchVehicle);
    const compatibleOrbits = vehicle && vehicle.compatible_orbits ? vehicle.compatible_orbits : null;

    container.innerHTML = orbits.map((o) => {
        const isCompatible = !compatibleOrbits || compatibleOrbits.includes(o.name);
        return `
            <div class="orbit-card glass-card ${window.AppState.orbit === o.name ? 'selected' : ''} ${!isCompatible ? 'disabled' : ''}"
                 data-orbit="${o.name}" ${!isCompatible ? 'title="Incompatible with selected launch vehicle"' : ''}>
                <h4 class="orbit-name" style="color:#fff;">${o.name}</h4>
                <p class="orbit-altitude" style="font-size:0.8rem;color:var(--accent-cyan);">${o.altitude || ''}</p>
                <p class="orbit-desc" style="font-size:0.85rem;color:var(--text-secondary);margin:6px 0;">${o.description || ''}</p>
                ${!isCompatible ? '<span class="launch-orbit-tag" style="background:var(--danger);color:#fff;">Incompatible</span>' : '<button class="btn btn-outline btn-sm" style="margin-top:8px;">Select Orbit</button>'}
            </div>
        `;
    }).join('');

    // Click handlers
    container.querySelectorAll('.orbit-card:not(.disabled)').forEach((card) => {
        card.addEventListener('click', () => {
            container.querySelectorAll('.orbit-card').forEach((c) => c.classList.remove('selected'));
            card.classList.add('selected');
            window.AppState.orbit = card.dataset.orbit;
            recalculateResources();
            if (typeof window.showNotification === 'function') {
                window.showNotification(`Orbit selected: ${card.dataset.orbit}`, 'success');
            }
        });
    });
}

// ─── Dashboard Initialisation ──────────────────────────────

/**
 * Called when navigating to the #resource-dashboard page.
 * Sets up everything: vehicles, orbits, charts, resources, launch button.
 */
function initDashboard() {
    renderLaunchVehicles();
    renderOrbits();
    initDashboardCharts();
    recalculateResources();

    // Wire up the launch simulation button
    const launchBtn = document.getElementById('btn-initiate-simulation') || document.getElementById('btn-launch-simulation');
    if (launchBtn) {
        const fresh = launchBtn.cloneNode(true);
        launchBtn.parentNode.replaceChild(fresh, launchBtn);

        fresh.addEventListener('click', () => {
            const warnings = checkConstraints();
            const hasErrors = warnings.some((w) => w.type === 'error');
            if (hasErrors) {
                window.showNotification('Cannot launch: resolve all engineering errors first.', 'error');
                return;
            }
            window.navigateTo('simulation-page');
        });
    }
}

window.initDashboard = initDashboard;

// ─── Exported Dashboard Namespace ──────────────────────────

window.Dashboard = {
    recalculateResources,
    initDashboardCharts,
    updateCharts,
    updateResourceBars,
    checkConstraints,
    renderLaunchVehicles,
    renderOrbits,
    initDashboard,
    renderConstraintWarnings,
};
