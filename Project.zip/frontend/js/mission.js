/* ===================================================================
   ORBIT COMMAND — mission.js
   Mission Selection, Spacecraft Configuration, Team Mode,
   Saved Missions Management, and Educational Guides.
   =================================================================== */

// Icon map for missions
const MISSION_ICONS = {
    mars_exploration: '🔴',
    mars: '🔴',
    lunar_research: '🌙',
    lunar: '🌙',
    earth_observation: '🌍',
    earth: '🌍',
    deep_space: '🌌',
    asteroid_exploration: '☄️',
    asteroid: '☄️',
};

/* ---------------------------------------------------------------
   A. Mission Selection Page (#mission-select)
   --------------------------------------------------------------- */
function initMissionSelect() {
    // Bind click events on all pre-rendered mission cards in index.html
    const selectBtns = document.querySelectorAll('.select-mission-btn');
    selectBtns.forEach(btn => {
        const fresh = btn.cloneNode(true);
        btn.parentNode.replaceChild(fresh, btn);

        fresh.addEventListener('click', (e) => {
            const missionTypeKey = e.target.dataset.missionType || e.target.closest('.mission-card')?.dataset.mission;
            selectMissionByKey(missionTypeKey);
        });
    });
}

function selectMissionByKey(key) {
    const state = window.AppState;
    const missionTypes = state.missionTypes || [];

    const matched = missionTypes.find(m => 
        (m.key && m.key.toLowerCase().includes(key.toLowerCase())) ||
        (m.id && m.id.toLowerCase().includes(key.toLowerCase())) ||
        (m.name && m.name.toLowerCase().includes(key.toLowerCase()))
    ) || {
        name: key.toUpperCase() + ' Exploration',
        key: key,
        budget: 500,
        required_components: ['Propulsion System'],
        recommended_instruments: ['High Resolution Camera']
    };

    selectMission(matched);
}

function selectMission(missionType) {
    const state = window.AppState;
    state.selectedMission = missionType;
    state.missionBudget = missionType.budget || 500;
    state.spacecraft = { components: [], instruments: [] };
    state.launchVehicle = null;
    state.orbit = null;

    // Auto-select required components for this mission
    if (missionType.required_components) {
        missionType.required_components.forEach(comp => {
            if (!state.spacecraft.components.includes(comp)) {
                state.spacecraft.components.push(comp);
            }
        });
    }

    if (typeof window.recalculateResources === 'function') {
        window.recalculateResources();
    }

    window.navigateTo('mission-config');
}

/* ---------------------------------------------------------------
   B. Mission Config Page (#mission-config)
   --------------------------------------------------------------- */
function initMissionConfig() {
    const state = window.AppState;
    const mission = state.selectedMission;
    if (!mission) {
        window.navigateTo('mission-select');
        return;
    }

    // Set Objective Header
    const objEl = document.getElementById('config-mission-objective');
    if (objEl) {
        objEl.innerHTML = `<strong>${mission.name}:</strong> ${mission.description || mission.focus || 'Configure your spacecraft components, instruments, and orbital parameters.'} (Budget: <strong>$${mission.budget}M</strong>)`;
    }

    // Spacecraft Type Selector
    const typeCards = document.querySelectorAll('.spacecraft-type-selector .type-card');
    typeCards.forEach(tc => {
        tc.onclick = () => {
            typeCards.forEach(c => c.classList.remove('selected'));
            tc.classList.add('selected');
            state.spacecraftType = tc.dataset.type;
            window.showNotification(`Spacecraft architecture set to: ${tc.dataset.type.toUpperCase()}`, 'info');
        };
    });

    // Config Tabs Navigation
    const tabBtns = document.querySelectorAll('.config-tabs .tab-btn');
    const tabPanes = document.querySelectorAll('.config-tabs .tab-pane');
    tabBtns.forEach(btn => {
        btn.onclick = () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            const targetPane = document.getElementById(btn.dataset.tab);
            if (targetPane) targetPane.classList.add('active');
        };
    });

    // Populate Tab: Components
    renderConfigComponents();

    // Populate Tab: Instruments
    renderConfigInstruments();

    // Populate Tab: Launch Vehicles
    renderConfigLaunchVehicles();

    // Populate Tab: Orbits
    renderConfigOrbits();

    // Wire Proceed to Launch & Build Spacecraft buttons
    const proceedBtn = document.getElementById('btn-proceed-launch');
    if (proceedBtn) {
        proceedBtn.disabled = false;
        proceedBtn.onclick = () => {
            window.navigateTo('resource-dashboard');
        };
    }

    const buildBtn = document.getElementById('btn-go-builder');
    if (buildBtn) {
        buildBtn.onclick = () => {
            window.navigateTo('spacecraft-builder');
        };
    }

    updateConfigSummary();
}

/**
 * Render components inside Config Tab
 */
function renderConfigComponents() {
    const container = document.getElementById('config-component-list');
    if (!container) return;

    const state = window.AppState;
    const comps = state.componentsList || [];
    const mission = state.selectedMission || {};
    const required = mission.required_components || [];

    container.innerHTML = `
        <div class="config-grid">
            ${comps.map(c => {
                const isSelected = (state.spacecraft.components || []).includes(c.name);
                const isReq = required.includes(c.name);
                return `
                <div class="config-card glass-card ${isSelected ? 'selected' : ''} ${isReq ? 'required' : ''}" data-comp-name="${c.name}">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                        <h4 style="color:#fff;font-size:1rem;">${c.name}</h4>
                        ${isReq ? '<span style="font-size:0.7rem;background:var(--warning);color:#060b18;padding:2px 6px;border-radius:4px;font-weight:700;">REQUIRED</span>' : ''}
                    </div>
                    <p style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:8px;">${c.description}</p>
                    <div style="display:flex;gap:12px;font-size:0.75rem;color:var(--accent-cyan);">
                        <span>⚖️ ${c.mass} kg</span>
                        <span>⚡ ${c.power_generation ? '+' + c.power_generation : '-' + c.power_consumption} W</span>
                        <span>💰 $${c.cost}M</span>
                    </div>
                </div>`;
            }).join('')}
        </div>
    `;

    container.querySelectorAll('.config-card').forEach(card => {
        card.onclick = () => {
            toggleComponent(card.dataset.compName);
            renderConfigComponents();
            updateConfigSummary();
        };
    });
}

/**
 * Render instruments inside Config Tab
 */
function renderConfigInstruments() {
    const container = document.getElementById('config-instrument-list');
    if (!container) return;

    const state = window.AppState;
    const insts = state.instrumentsList || [];
    const mission = state.selectedMission || {};
    const recommended = mission.recommended_instruments || [];

    container.innerHTML = `
        <div class="config-grid">
            ${insts.map(i => {
                const isSelected = (state.spacecraft.instruments || []).includes(i.name);
                const isRec = recommended.includes(i.name);
                return `
                <div class="config-card glass-card ${isSelected ? 'selected' : ''}" data-inst-name="${i.name}">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                        <h4 style="color:#fff;font-size:1rem;">${i.name}</h4>
                        ${isRec ? '<span style="font-size:0.7rem;background:var(--accent-cyan);color:#060b18;padding:2px 6px;border-radius:4px;font-weight:700;">RECOMMENDED</span>' : ''}
                    </div>
                    <p style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:8px;">${i.description}</p>
                    <div style="display:flex;gap:10px;font-size:0.75rem;color:var(--accent-cyan);flex-wrap:wrap;">
                        <span>⚖️ ${i.mass} kg</span>
                        <span>⚡ -${i.power_consumption} W</span>
                        <span>💰 $${i.cost}M</span>
                        <span>📊 Sci +${i.sci_value}</span>
                    </div>
                </div>`;
            }).join('')}
        </div>
    `;

    container.querySelectorAll('.config-card').forEach(card => {
        card.onclick = () => {
            toggleInstrument(card.dataset.instName);
            renderConfigInstruments();
            updateConfigSummary();
        };
    });
}

/**
 * Render Launch Vehicles inside Config Tab
 */
function renderConfigLaunchVehicles() {
    const container = document.getElementById('config-launch-vehicles');
    if (!container) return;
    const state = window.AppState;

    container.innerHTML = `
        <div class="launch-vehicles-grid">
            ${(state.launchVehicles || []).map(lv => `
                <div class="launch-card glass-card ${state.launchVehicle === lv.name ? 'selected' : ''}" data-lv="${lv.name}">
                    <h4 style="color:#fff;">${lv.name}</h4>
                    <p style="font-size:0.8rem;color:var(--text-secondary);">${lv.description}</p>
                    <div style="margin:10px 0;font-size:0.85rem;color:var(--accent-cyan);">
                        <strong>Payload:</strong> ${lv.payload_capacity} kg | <strong>Cost:</strong> $${lv.cost}M
                    </div>
                    <button class="btn btn-outline btn-sm select-lv-btn">Select</button>
                </div>
            `).join('')}
        </div>
    `;

    container.querySelectorAll('.launch-card').forEach(card => {
        card.onclick = () => {
            state.launchVehicle = card.dataset.lv;
            renderConfigLaunchVehicles();
            if (typeof window.recalculateResources === 'function') {
                window.recalculateResources();
            }
            updateConfigSummary();
        };
    });
}

/**
 * Render Orbits inside Config Tab
 */
function renderConfigOrbits() {
    const container = document.getElementById('config-orbit-list');
    if (!container) return;
    const state = window.AppState;

    container.innerHTML = `
        <div class="orbit-grid">
            ${(state.orbits || []).map(orb => `
                <div class="orbit-card glass-card ${state.orbit === orb.name ? 'selected' : ''}" data-orb="${orb.name}">
                    <h4 style="color:#fff;">${orb.name}</h4>
                    <p style="font-size:0.8rem;color:var(--text-secondary);">${orb.description}</p>
                    <p style="font-size:0.75rem;color:var(--accent-cyan);margin-top:6px;"><strong>Alt:</strong> ${orb.altitude}</p>
                    <button class="btn btn-outline btn-sm" style="margin-top:10px;">Select</button>
                </div>
            `).join('')}
        </div>
    `;

    container.querySelectorAll('.orbit-card').forEach(card => {
        card.onclick = () => {
            state.orbit = card.dataset.orb;
            renderConfigOrbits();
            if (typeof window.recalculateResources === 'function') {
                window.recalculateResources();
            }
            updateConfigSummary();
        };
    });
}

function toggleComponent(name) {
    const state = window.AppState;
    if (!state.spacecraft.components) state.spacecraft.components = [];

    const idx = state.spacecraft.components.indexOf(name);
    if (idx >= 0) {
        state.spacecraft.components.splice(idx, 1);
    } else {
        state.spacecraft.components.push(name);
    }

    if (typeof window.recalculateResources === 'function') {
        window.recalculateResources();
    }
}

function toggleInstrument(name) {
    const state = window.AppState;
    if (!state.spacecraft.instruments) state.spacecraft.instruments = [];

    const idx = state.spacecraft.instruments.indexOf(name);
    if (idx >= 0) {
        state.spacecraft.instruments.splice(idx, 1);
    } else {
        state.spacecraft.instruments.push(name);
    }

    if (typeof window.recalculateResources === 'function') {
        window.recalculateResources();
    }
}

/**
 * Update Side Panel Resource Summary on the Config Page
 */
function updateConfigSummary() {
    const state = window.AppState;
    const res = state.resources;
    const budget = state.missionBudget || 500;

    // Mass
    const massEl = document.getElementById('summary-mass');
    const massBar = document.getElementById('summary-mass-bar');
    if (massEl) massEl.textContent = `${Math.round(res.totalMass)} kg`;
    if (massBar) massBar.style.width = `${Math.min(100, Math.round((res.totalMass / 2000) * 100))}%`;

    // Power
    const powerEl = document.getElementById('summary-power');
    const powerBar = document.getElementById('summary-power-bar');
    if (powerEl) powerEl.textContent = `${Math.round(res.availablePower)} W`;
    if (powerBar) powerBar.style.width = `${Math.min(100, Math.max(0, Math.round((res.availablePower / 800) * 100)))}%`;

    // Cost
    const costEl = document.getElementById('summary-cost');
    const costBar = document.getElementById('summary-cost-bar');
    if (costEl) costEl.textContent = `$${Math.round(res.totalCost)}M / $${Math.round(budget)}M`;
    if (costBar) {
        const costPct = Math.min(100, Math.round((res.totalCost / budget) * 100));
        costBar.style.width = `${costPct}%`;
        costBar.style.background = res.totalCost > budget ? 'var(--danger)' : 'linear-gradient(90deg, #f59e0b, #fbbf24)';
    }

    // Data Rate
    const dataEl = document.getElementById('summary-data-rate');
    const dataBar = document.getElementById('summary-data-bar');
    if (dataEl) dataEl.textContent = `${Math.round(res.dataRate)} Mbps`;
    if (dataBar) dataBar.style.width = `${Math.min(100, Math.round((res.dataRate / 400) * 100))}%`;
}

/* ---------------------------------------------------------------
   C. Team Mode Page (#team-mode)
   --------------------------------------------------------------- */
function initTeamMode() {
    const state = window.AppState;

    // Set input listeners on the 4 roles
    const roles = ['commander', 'engineer', 'scientist', 'comms'];
    roles.forEach(r => {
        const input = document.getElementById(`team-${r}-name`);
        if (input) {
            if (state.team[r]) input.value = state.team[r];
            input.oninput = () => {
                state.team[r === 'comms' ? 'comms_officer' : r] = input.value.trim();
            };
        }
    });
}

/* ---------------------------------------------------------------
   D. Saved Missions Page (#saved-missions)
   --------------------------------------------------------------- */
async function initSavedMissions() {
    const tbody = document.getElementById('saved-missions-tbody');
    if (!tbody) return;

    tbody.innerHTML = `<tr><td colspan="5" class="empty-message">Loading missions from database...</td></tr>`;

    try {
        const missions = await window.apiGet('/api/missions');
        window.AppState.savedMissions = missions || [];

        if (missions.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="empty-message">No saved missions yet. Complete and save a mission to see it here!</td></tr>`;
            return;
        }

        tbody.innerHTML = missions.map(m => `
            <tr>
                <td style="font-weight:700;color:#fff;">${m.name}</td>
                <td><span class="launch-orbit-tag">${m.mission_type}</span></td>
                <td><strong style="color:var(--accent-cyan);">${m.score != null ? Math.round(m.score) : '—'}</strong> / 100</td>
                <td>${m.created_at ? new Date(m.created_at).toLocaleDateString() : 'Recent'}</td>
                <td>
                    <button class="btn btn-xs btn-primary load-btn" data-id="${m.id}">Load</button>
                    <button class="btn btn-xs btn-secondary delete-btn" data-id="${m.id}" style="color:var(--danger);">Delete</button>
                </td>
            </tr>
        `).join('');

        // Bind Load & Delete
        tbody.querySelectorAll('.load-btn').forEach(btn => {
            btn.onclick = () => loadMission(parseInt(btn.dataset.id));
        });
        tbody.querySelectorAll('.delete-btn').forEach(btn => {
            btn.onclick = () => deleteMission(parseInt(btn.dataset.id));
        });
    } catch (err) {
        tbody.innerHTML = `<tr><td colspan="5" class="empty-message" style="color:var(--danger);">Failed to load missions from server.</td></tr>`;
    }
}

async function loadMission(missionId) {
    try {
        const m = await window.apiGet(`/api/missions/${missionId}`);
        const state = window.AppState;

        const mType = (state.missionTypes || []).find(t => (t.id === m.mission_type || t.key === m.mission_type));
        state.selectedMission = mType || { name: m.name, id: m.mission_type, budget: 500 };
        state.missionBudget = state.selectedMission.budget || 500;
        state.spacecraft = {
            components: m.spacecraft_config || [],
            instruments: m.instruments || []
        };
        state.launchVehicle = m.launch_vehicle;
        state.orbit = m.orbit;
        if (m.team) state.team = m.team;

        if (typeof window.recalculateResources === 'function') {
            window.recalculateResources();
        }

        window.showNotification(`Loaded mission: ${m.name}`, 'success');
        window.navigateTo('resource-dashboard');
    } catch (err) {
        window.showNotification('Could not load mission', 'error');
    }
}

async function deleteMission(missionId) {
    if (!confirm('Are you sure you want to delete this mission record?')) return;
    try {
        await window.apiDelete(`/api/missions/${missionId}`);
        window.showNotification('Mission record deleted', 'info');
        initSavedMissions();
    } catch (err) {
        window.showNotification('Failed to delete mission', 'error');
    }
}

/* ---------------------------------------------------------------
   E. Educational Guide Section (#learn-section)
   --------------------------------------------------------------- */
function initLearnSection() {
    const accordions = document.querySelectorAll('#learn-section .accordion-item');
    accordions.forEach(acc => {
        const header = acc.querySelector('.accordion-header');
        const body = acc.querySelector('.accordion-body');
        const icon = acc.querySelector('.accordion-icon');
        if (header && body) {
            header.onclick = () => {
                const isOpen = body.style.display === 'block';
                body.style.display = isOpen ? 'none' : 'block';
                if (icon) icon.textContent = isOpen ? '+' : '−';
            };
        }
    });
}

// Window Exports
window.initMissionSelect = initMissionSelect;
window.selectMission = selectMission;
window.initMissionConfig = initMissionConfig;
window.toggleComponent = toggleComponent;
window.toggleInstrument = toggleInstrument;
window.initTeamMode = initTeamMode;
window.initSavedMissions = initSavedMissions;
window.loadMission = loadMission;
window.deleteMission = deleteMission;
window.initLearnSection = initLearnSection;
window.updateConfigSummary = updateConfigSummary;
