"""
main.py — FastAPI application for Orbit Command.

Provides REST endpoints for mission CRUD, simulation, leaderboard,
and static reference data (components, instruments, vehicles, orbits,
mission types).  Serves the frontend as static files from ../frontend/.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from database import database, missions, leaderboard, connect_db, disconnect_db
from data import (
    SPACECRAFT_COMPONENTS,
    INSTRUMENTS,
    LAUNCH_VEHICLES,
    ORBITS,
    MISSION_TYPES,
)
from models import (
    MissionCreate,
    MissionUpdate,
    MissionResponse,
    SimulationRequest,
    SimulationResponse,
    SimulationEvent,
    ScoreBreakdown,
    MissionReport,
    LeaderboardEntry,
    TeamConfig,
)
from simulator import run_simulation
from scoring import calculate_score

# ── App setup ────────────────────────────────────────────────────

app = FastAPI(
    title="Orbit Command API",
    description="Backend for the Space Mission Design Simulator",
    version="1.0.0",
)

# CORS — allow all origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Lifecycle events ─────────────────────────────────────────────

@app.on_event("startup")
async def startup() -> None:
    """Create tables (if not exist) and open the database connection."""
    await connect_db()


@app.on_event("shutdown")
async def shutdown() -> None:
    """Close the database connection."""
    await disconnect_db()


# ── Helpers ──────────────────────────────────────────────────────

def _now_iso() -> str:
    """Return current UTC timestamp as ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


def _row_to_mission_response(row: Any) -> MissionResponse:
    """Convert a database row (mapping) into a MissionResponse model."""
    spacecraft_config = json.loads(row["spacecraft_config"]) if row["spacecraft_config"] else []
    instruments_list = json.loads(row["instruments"]) if row["instruments"] else []
    team_raw = json.loads(row["team"]) if row["team"] else {}
    report_raw = json.loads(row["report"]) if row["report"] else None

    return MissionResponse(
        id=row["id"],
        name=row["name"],
        mission_type=row["mission_type"],
        spacecraft_config=spacecraft_config,
        instruments=instruments_list,
        launch_vehicle=row["launch_vehicle"] or "",
        orbit=row["orbit"] or "",
        team=TeamConfig(**team_raw) if team_raw else TeamConfig(),
        status=row["status"] or "draft",
        score=row["score"],
        report=report_raw,
        created_at=row["created_at"] or "",
        updated_at=row["updated_at"] or "",
    )


# ══════════════════════════════════════════════════════════════════
# MISSION CRUD
# ══════════════════════════════════════════════════════════════════

@app.get("/api/missions", response_model=list[MissionResponse])
async def list_missions() -> list[MissionResponse]:
    """Return all saved missions, newest first."""
    query = missions.select().order_by(missions.c.id.desc())
    rows = await database.fetch_all(query)
    return [_row_to_mission_response(r) for r in rows]


@app.post("/api/missions", response_model=MissionResponse, status_code=201)
async def create_mission(payload: MissionCreate) -> MissionResponse:
    """Create a new mission record."""
    now = _now_iso()
    values = {
        "name": payload.name,
        "mission_type": payload.mission_type,
        "spacecraft_config": json.dumps(payload.components),
        "instruments": json.dumps(payload.instruments),
        "launch_vehicle": payload.launch_vehicle,
        "orbit": payload.orbit,
        "team": json.dumps(payload.team.model_dump()),
        "status": "draft",
        "score": None,
        "report": None,
        "created_at": now,
        "updated_at": now,
    }
    query = missions.insert()
    last_id = await database.execute(query=query, values=values)

    # Fetch inserted row
    row = await database.fetch_one(missions.select().where(missions.c.id == last_id))
    if not row:
        raise HTTPException(status_code=500, detail="Failed to retrieve created mission.")
    return _row_to_mission_response(row)


@app.get("/api/missions/{mission_id}", response_model=MissionResponse)
async def get_mission(mission_id: int) -> MissionResponse:
    """Return a single mission by its ID."""
    row = await database.fetch_one(missions.select().where(missions.c.id == mission_id))
    if not row:
        raise HTTPException(status_code=404, detail=f"Mission {mission_id} not found.")
    return _row_to_mission_response(row)


@app.put("/api/missions/{mission_id}", response_model=MissionResponse)
async def update_mission(mission_id: int, payload: MissionUpdate) -> MissionResponse:
    """Update an existing mission. Only provided fields are changed."""
    row = await database.fetch_one(missions.select().where(missions.c.id == mission_id))
    if not row:
        raise HTTPException(status_code=404, detail=f"Mission {mission_id} not found.")

    update_data: dict[str, Any] = {"updated_at": _now_iso()}

    if payload.name is not None:
        update_data["name"] = payload.name
    if payload.mission_type is not None:
        update_data["mission_type"] = payload.mission_type
    if payload.components is not None:
        update_data["spacecraft_config"] = json.dumps(payload.components)
    if payload.instruments is not None:
        update_data["instruments"] = json.dumps(payload.instruments)
    if payload.launch_vehicle is not None:
        update_data["launch_vehicle"] = payload.launch_vehicle
    if payload.orbit is not None:
        update_data["orbit"] = payload.orbit
    if payload.team is not None:
        update_data["team"] = json.dumps(payload.team.model_dump())
    if payload.status is not None:
        update_data["status"] = payload.status

    query = missions.update().where(missions.c.id == mission_id).values(**update_data)
    await database.execute(query)

    updated_row = await database.fetch_one(missions.select().where(missions.c.id == mission_id))
    if not updated_row:
        raise HTTPException(status_code=500, detail="Failed to fetch updated mission.")
    return _row_to_mission_response(updated_row)


@app.delete("/api/missions/{mission_id}")
async def delete_mission(mission_id: int) -> dict[str, str]:
    """Delete a mission by ID."""
    row = await database.fetch_one(missions.select().where(missions.c.id == mission_id))
    if not row:
        raise HTTPException(status_code=404, detail=f"Mission {mission_id} not found.")
    await database.execute(missions.delete().where(missions.c.id == mission_id))
    return {"detail": f"Mission {mission_id} deleted."}


# ══════════════════════════════════════════════════════════════════
# SIMULATION
# ══════════════════════════════════════════════════════════════════

@app.post("/api/simulate", response_model=SimulationResponse)
async def simulate_mission(payload: SimulationRequest) -> SimulationResponse:
    """Run a full simulation for the given mission configuration.

    Returns events, score breakdown, and a detailed report.
    """
    # Run the simulation engine
    sim_result = run_simulation(
        mission_name=payload.mission_name,
        mission_type=payload.mission_type,
        component_names=payload.components,
        instrument_names=payload.instruments,
        launch_vehicle_name=payload.launch_vehicle,
        orbit_name=payload.orbit,
        team=payload.team.model_dump(),
    )

    # Calculate scores
    score_result = calculate_score(
        mission_type=payload.mission_type,
        component_names=payload.components,
        instrument_names=payload.instruments,
        orbit_name=payload.orbit,
        simulation_result=sim_result,
    )

    # Build response models
    events = [
        SimulationEvent(
            phase=e["phase"],
            event_type=e["event_type"],
            description=e["description"],
            impact=e.get("impact", {}),
        )
        for e in sim_result["events"]
    ]

    sb = score_result["score_breakdown"]
    score_breakdown = ScoreBreakdown(
        scientific_achievement=sb["scientific_achievement"],
        resource_efficiency=sb["resource_efficiency"],
        engineering_reliability=sb["engineering_reliability"],
        communication_performance=sb["communication_performance"],
        mission_objective_completion=sb["mission_objective_completion"],
        total=sb["total"],
        achievement_level=sb["achievement_level"],
    )

    report = MissionReport(
        score_breakdown=score_breakdown,
        recommendations=score_result["recommendations"],
        phase_results=sim_result["phase_results"],
        resource_summary=sim_result["resources"],
    )

    return SimulationResponse(
        mission_name=payload.mission_name,
        mission_type=payload.mission_type,
        events=events,
        score=score_breakdown,
        report=report,
    )


# ══════════════════════════════════════════════════════════════════
# LEADERBOARD
# ══════════════════════════════════════════════════════════════════

@app.get("/api/leaderboard", response_model=list[LeaderboardEntry])
async def get_leaderboard() -> list[LeaderboardEntry]:
    """Return top 50 leaderboard entries, ordered by score descending."""
    query = leaderboard.select().order_by(leaderboard.c.score.desc()).limit(50)
    rows = await database.fetch_all(query)
    return [
        LeaderboardEntry(
            id=r["id"],
            mission_id=r["mission_id"],
            player_name=r["player_name"],
            score=r["score"],
            mission_type=r["mission_type"],
            created_at=r["created_at"],
        )
        for r in rows
    ]


# ══════════════════════════════════════════════════════════════════
# STATIC REFERENCE DATA
# ══════════════════════════════════════════════════════════════════

@app.get("/api/components")
async def get_components() -> list[dict[str, Any]]:
    """Return all available spacecraft components with stats."""
    return SPACECRAFT_COMPONENTS


@app.get("/api/instruments")
async def get_instruments() -> list[dict[str, Any]]:
    """Return all available scientific instruments with stats."""
    return INSTRUMENTS


@app.get("/api/launch-vehicles")
async def get_launch_vehicles() -> list[dict[str, Any]]:
    """Return all available launch vehicles."""
    return LAUNCH_VEHICLES


@app.get("/api/orbits")
async def get_orbits() -> list[dict[str, Any]]:
    """Return all orbit options."""
    return ORBITS


@app.get("/api/mission-types")
async def get_mission_types() -> list[dict[str, Any]]:
    """Return all mission type definitions."""
    return [
        {**v, "key": k} for k, v in MISSION_TYPES.items()
    ]


# ══════════════════════════════════════════════════════════════════
# STATIC FILES — serve the frontend
# ══════════════════════════════════════════════════════════════════

_frontend_dir = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.isdir(_frontend_dir):
    app.mount("/", StaticFiles(directory=_frontend_dir, html=True), name="frontend")
