"""
models.py — Pydantic models for all request / response schemas
used by the Orbit Command API.
"""

from __future__ import annotations

from typing import Any, Optional
from pydantic import BaseModel, Field


# ── Enums-as-models ──────────────────────────────────────────────

class SpacecraftComponent(BaseModel):
    """Static definition of one spacecraft component."""
    name: str
    mass: float
    power_generation: float = 0
    power_consumption: float = 0
    cost: float
    comm_capacity: float = 0
    reliability_bonus: float = 0
    description: str = ""


class Instrument(BaseModel):
    """Static definition of one scientific instrument."""
    name: str
    mass: float
    power_consumption: float
    cost: float
    sci_value: float
    data_rate: float
    description: str = ""


class LaunchVehicle(BaseModel):
    """Static definition of a launch vehicle."""
    name: str
    payload_capacity: float
    cost: float
    compatible_orbits: list[str]
    description: str = ""


class OrbitType(BaseModel):
    """Static definition of an orbit."""
    name: str
    complexity: int
    comm_factor: float
    duration_factor: float
    sci_bonus: float
    altitude: str
    description: str = ""


class MissionType(BaseModel):
    """Static definition of a mission type."""
    name: str
    key: str
    budget: float
    required_orbits: list[str]
    required_components: list[str] = []
    recommended_instruments: list[str] = []
    description: str = ""
    focus: str = ""


# ── Team ─────────────────────────────────────────────────────────

class TeamConfig(BaseModel):
    """Crew / team members for a mission."""
    commander: str = "Commander"
    engineer: str = "Engineer"
    scientist: str = "Scientist"
    comms_officer: str = "Comms Officer"


# ── Mission CRUD ─────────────────────────────────────────────────

class MissionCreate(BaseModel):
    """Payload for creating a new mission."""
    name: str
    mission_type: str
    components: list[str] = Field(default_factory=list)
    instruments: list[str] = Field(default_factory=list)
    launch_vehicle: str = ""
    orbit: str = ""
    team: TeamConfig = Field(default_factory=TeamConfig)


class MissionUpdate(BaseModel):
    """Payload for updating an existing mission (all fields optional)."""
    name: Optional[str] = None
    mission_type: Optional[str] = None
    components: Optional[list[str]] = None
    instruments: Optional[list[str]] = None
    launch_vehicle: Optional[str] = None
    orbit: Optional[str] = None
    team: Optional[TeamConfig] = None
    status: Optional[str] = None


class MissionResponse(BaseModel):
    """Full mission record returned by the API."""
    id: int
    name: str
    mission_type: str
    spacecraft_config: list[str] = Field(default_factory=list)
    instruments: list[str] = Field(default_factory=list)
    launch_vehicle: str = ""
    orbit: str = ""
    team: TeamConfig = Field(default_factory=TeamConfig)
    status: str = "draft"
    score: Optional[float] = None
    report: Optional[dict[str, Any]] = None
    created_at: str = ""
    updated_at: str = ""


# ── Simulation ───────────────────────────────────────────────────

class SimulationRequest(BaseModel):
    """Payload for POST /api/simulate."""
    mission_name: str
    mission_type: str
    components: list[str] = Field(default_factory=list)
    instruments: list[str] = Field(default_factory=list)
    launch_vehicle: str
    orbit: str
    team: TeamConfig = Field(default_factory=TeamConfig)


class SimulationEvent(BaseModel):
    """A single event that occurs during a simulation phase."""
    phase: str
    event_type: str          # e.g. "power_surge", "bonus_discovery", etc.
    description: str
    impact: dict[str, Any] = Field(default_factory=dict)


class ScoreBreakdown(BaseModel):
    """Detailed breakdown of the mission score."""
    scientific_achievement: float = 0.0
    resource_efficiency: float = 0.0
    engineering_reliability: float = 0.0
    communication_performance: float = 0.0
    mission_objective_completion: float = 0.0
    total: float = 0.0
    achievement_level: str = ""


class MissionReport(BaseModel):
    """Full post-mission report."""
    score_breakdown: ScoreBreakdown
    recommendations: list[str] = Field(default_factory=list)
    phase_results: list[dict[str, Any]] = Field(default_factory=list)
    resource_summary: dict[str, Any] = Field(default_factory=dict)


class SimulationResponse(BaseModel):
    """Returned by POST /api/simulate."""
    mission_name: str
    mission_type: str
    events: list[SimulationEvent] = Field(default_factory=list)
    score: ScoreBreakdown
    report: MissionReport


# ── Leaderboard ──────────────────────────────────────────────────

class LeaderboardEntry(BaseModel):
    """One row on the leaderboard."""
    id: int
    mission_id: int
    player_name: str
    score: float
    mission_type: str
    created_at: str
