"""
scoring.py — Score calculator for Orbit Command missions.

Evaluates a completed simulation across five categories (total 100 pts)
and produces textual recommendations explaining why the mission
succeeded or failed.
"""

from __future__ import annotations

from typing import Any

from data import (
    get_instrument_by_name,
    get_orbit_by_name,
    MISSION_TYPES,
)


# ── Achievement level thresholds ─────────────────────────────────

def _achievement_level(total: float) -> str:
    """Map a numeric score to an achievement label."""
    if total >= 90:
        return "Legendary"
    if total >= 75:
        return "Excellent"
    if total >= 60:
        return "Successful"
    if total >= 40:
        return "Partial Success"
    return "Failure"


# ── Category scorers ─────────────────────────────────────────────

def _scientific_achievement(
    instrument_names: list[str],
    orbit_name: str,
    data_remaining: float,
    bonus_discoveries: int,
) -> tuple[float, list[str]]:
    """Scientific Achievement — up to 30 pts.

    Factors:
    - Total sci_value of selected instruments (0-20 pts scaled)
    - Orbit science bonus (0-5 pts scaled)
    - Bonus discoveries during simulation (0-5 pts, 2.5 each)
    """
    recommendations: list[str] = []

    # Instrument science value (max raw ≈ 84 for all 7 instruments)
    total_sci = sum(
        (inst.get("sci_value", 0) if (inst := get_instrument_by_name(n)) else 0)
        for n in instrument_names
    )
    # Scale to 0-20: 84 → 20
    instr_pts = min(total_sci / 84 * 20, 20.0)

    if total_sci < 20:
        recommendations.append(
            "Consider adding more scientific instruments to increase research value."
        )

    # Orbit science bonus (max raw = 35 for Mars Transfer)
    orbit = get_orbit_by_name(orbit_name)
    orbit_sci_bonus = orbit.get("sci_bonus", 0) if orbit else 0
    orbit_pts = min(orbit_sci_bonus / 35 * 5, 5.0)

    # Bonus discoveries
    disc_pts = min(bonus_discoveries * 2.5, 5.0)
    if bonus_discoveries > 0:
        recommendations.append(
            f"Excellent! {bonus_discoveries} bonus scientific discovery(ies) boosted your score."
        )

    score = round(instr_pts + orbit_pts + disc_pts, 2)
    return score, recommendations


def _resource_efficiency(
    resources: dict[str, float],
    mission_budget: float,
) -> tuple[float, list[str]]:
    """Resource Efficiency — up to 20 pts.

    - Remaining budget ratio (0-8 pts)
    - Mass margin ratio (0-6 pts)
    - Power margin ratio (0-6 pts)
    """
    recommendations: list[str] = []

    # Budget ratio
    budget_ratio = max(resources.get("budget", 0), 0) / max(mission_budget, 1)
    budget_pts = min(budget_ratio * 16, 8.0)  # 50 % remaining → 8 pts
    if budget_ratio < 0:
        recommendations.append("Mission went over budget — try cheaper components or a smaller launcher.")

    # Mass margin
    mass = resources.get("mass_margin", 0)
    if mass >= 0:
        mass_pts = min(mass / 2000 * 6, 6.0)
    else:
        mass_pts = 0.0
        recommendations.append("Payload exceeded launcher capacity — reduce mass or upgrade the launcher.")

    # Power margin
    power = resources.get("power", 0)
    if power >= 0:
        power_pts = min(power / 500 * 6, 6.0)
    else:
        power_pts = 0.0
        recommendations.append("Power deficit detected — add solar panels or batteries.")

    score = round(budget_pts + mass_pts + power_pts, 2)
    return score, recommendations


def _engineering_reliability(
    component_names: list[str],
    phase_results: list[dict[str, Any]],
) -> tuple[float, list[str]]:
    """Engineering Reliability — up to 20 pts.

    - Component redundancy / coverage (0-8 pts)
    - Thermal control present (0-4 pts)
    - Phase success rate (0-8 pts)
    """
    recommendations: list[str] = []

    # Component coverage: 8 possible components → up to 8 pts (1 pt each)
    coverage_pts = min(len(component_names), 8.0)

    # Thermal control bonus
    thermal_pts = 4.0 if "Thermal Control System" in component_names else 0.0
    if thermal_pts == 0:
        recommendations.append("Adding a Thermal Control System would improve reliability.")

    # Phase success rate
    total_phases = len(phase_results)
    succeeded = sum(1 for p in phase_results if p.get("success", False))
    success_rate = succeeded / max(total_phases, 1)
    phase_pts = round(success_rate * 8, 2)
    if success_rate < 0.7:
        recommendations.append("Too many phase failures — improve components to raise success probability.")

    score = round(coverage_pts + thermal_pts + phase_pts, 2)
    return score, recommendations


def _communication_performance(
    component_names: list[str],
    instrument_names: list[str],
    events: list[dict[str, Any]],
    orbit_name: str,
) -> tuple[float, list[str]]:
    """Communication Performance — up to 15 pts.

    - Antenna quality vs data generated (0-10 pts)
    - Comm-related events handled (0-5 pts)
    """
    recommendations: list[str] = []

    # Comm capacity from components
    from data import get_component_by_name  # local import to avoid circular at module level

    total_comm = 0.0
    for name in component_names:
        comp = get_component_by_name(name)
        if comp:
            total_comm += comp.get("comm_capacity", 0)

    total_data = 0.0
    for name in instrument_names:
        inst = get_instrument_by_name(name)
        if inst:
            total_data += inst.get("data_rate", 0)

    orbit = get_orbit_by_name(orbit_name)
    comm_factor = orbit.get("comm_factor", 1.0) if orbit else 1.0
    effective_comm = total_comm * comm_factor

    # Ratio of comm capacity to data demand
    if total_data > 0:
        ratio = effective_comm / total_data
    else:
        ratio = 1.0 if total_comm > 0 else 0.0

    antenna_pts = min(ratio * 10, 10.0)
    if ratio < 0.5:
        recommendations.append(
            "Communication capacity is insufficient for the data generated — add a High-Gain Antenna."
        )

    # Comm events handling: penalize unrecovered comm delays
    comm_events = [e for e in events if e.get("event_type") in ("comm_delay",)]
    penalty = len(comm_events) * 1.5
    event_pts = max(5.0 - penalty, 0.0)

    score = round(antenna_pts + event_pts, 2)
    return score, recommendations


def _mission_objective_completion(
    mission_type: str,
    component_names: list[str],
    instrument_names: list[str],
    orbit_name: str,
    phase_results: list[dict[str, Any]],
) -> tuple[float, list[str]]:
    """Mission Objective Completion — up to 15 pts.

    - Correct orbit selected (0-5 pts)
    - Required components present (0-5 pts)
    - Recommended instruments present (0-5 pts, proportional)
    """
    recommendations: list[str] = []
    mission_def = MISSION_TYPES.get(mission_type)
    if not mission_def:
        return 5.0, ["Unknown mission type — scoring with defaults."]

    # Orbit check
    required_orbits = mission_def.get("required_orbits", [])
    if orbit_name in required_orbits:
        orbit_pts = 5.0
    else:
        orbit_pts = 0.0
        recommendations.append(
            f"Orbit '{orbit_name}' is not optimal for this mission — consider: {', '.join(required_orbits)}."
        )

    # Required components
    req_comps = mission_def.get("required_components", [])
    if req_comps:
        present = sum(1 for c in req_comps if c in component_names)
        comp_pts = (present / len(req_comps)) * 5.0
        missing = [c for c in req_comps if c not in component_names]
        if missing:
            recommendations.append(f"Missing required components: {', '.join(missing)}.")
    else:
        comp_pts = 5.0  # no requirements → full marks

    # Recommended instruments
    rec_instr = mission_def.get("recommended_instruments", [])
    if rec_instr:
        present = sum(1 for i in rec_instr if i in instrument_names)
        instr_pts = (present / len(rec_instr)) * 5.0
        missing = [i for i in rec_instr if i not in instrument_names]
        if missing:
            recommendations.append(f"Consider adding recommended instruments: {', '.join(missing)}.")
    else:
        instr_pts = 5.0

    score = round(orbit_pts + comp_pts + instr_pts, 2)
    return score, recommendations


# ── Public API ───────────────────────────────────────────────────

def calculate_score(
    mission_type: str,
    component_names: list[str],
    instrument_names: list[str],
    orbit_name: str,
    simulation_result: dict[str, Any],
) -> dict[str, Any]:
    """Calculate the full score breakdown and recommendations.

    Args:
        mission_type:      key from MISSION_TYPES
        component_names:   list of selected component names
        instrument_names:  list of selected instrument names
        orbit_name:        selected orbit name
        simulation_result: dict returned by `simulator.run_simulation`

    Returns:
        dict with:
          score_breakdown  – per-category and total scores
          recommendations  – list of textual advice strings
          achievement_level – label string
    """
    resources: dict[str, float] = simulation_result.get("resources", {})
    events: list[dict[str, Any]] = simulation_result.get("events", [])
    phase_results: list[dict[str, Any]] = simulation_result.get("phase_results", [])
    bonus_discoveries: int = simulation_result.get("bonus_discoveries", 0)
    mission_budget = MISSION_TYPES.get(mission_type, {}).get("budget", 500)

    all_recommendations: list[str] = []

    # 1. Scientific Achievement (30 pts)
    sci_score, sci_recs = _scientific_achievement(
        instrument_names, orbit_name, resources.get("data", 0), bonus_discoveries
    )
    all_recommendations.extend(sci_recs)

    # 2. Resource Efficiency (20 pts)
    res_score, res_recs = _resource_efficiency(resources, mission_budget)
    all_recommendations.extend(res_recs)

    # 3. Engineering Reliability (20 pts)
    eng_score, eng_recs = _engineering_reliability(component_names, phase_results)
    all_recommendations.extend(eng_recs)

    # 4. Communication Performance (15 pts)
    comm_score, comm_recs = _communication_performance(
        component_names, instrument_names, events, orbit_name
    )
    all_recommendations.extend(comm_recs)

    # 5. Mission Objective Completion (15 pts)
    obj_score, obj_recs = _mission_objective_completion(
        mission_type, component_names, instrument_names, orbit_name, phase_results
    )
    all_recommendations.extend(obj_recs)

    total = round(sci_score + res_score + eng_score + comm_score + obj_score, 2)
    level = _achievement_level(total)

    return {
        "score_breakdown": {
            "scientific_achievement": sci_score,
            "resource_efficiency": res_score,
            "engineering_reliability": eng_score,
            "communication_performance": comm_score,
            "mission_objective_completion": obj_score,
            "total": total,
            "achievement_level": level,
        },
        "recommendations": all_recommendations,
        "achievement_level": level,
    }
