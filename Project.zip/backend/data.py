"""
data.py — Static reference data for Orbit Command.
All spacecraft components, instruments, launch vehicles, orbits,
and mission type definitions are kept here as plain Python dicts/lists.
"""

from typing import Any

# ---------------------------------------------------------------------------
# Spacecraft Components
# ---------------------------------------------------------------------------
SPACECRAFT_COMPONENTS: list[dict[str, Any]] = [
    {
        "name": "Solar Panels",
        "mass": 20,
        "power_generation": 500,
        "power_consumption": 0,
        "cost": 15,
        "comm_capacity": 0,
        "reliability_bonus": 0,
        "description": "Photovoltaic arrays converting sunlight to electricity",
    },
    {
        "name": "Rechargeable Batteries",
        "mass": 30,
        "power_generation": 200,
        "power_consumption": 0,
        "cost": 10,
        "comm_capacity": 0,
        "reliability_bonus": 0,
        "description": "Lithium-ion battery packs for power storage",
    },
    {
        "name": "High-Gain Antenna",
        "mass": 15,
        "power_consumption": 50,
        "power_generation": 0,
        "cost": 20,
        "comm_capacity": 500,
        "reliability_bonus": 0,
        "description": "Parabolic dish for long-range communication",
    },
    {
        "name": "Communication Transmitter",
        "mass": 10,
        "power_consumption": 30,
        "power_generation": 0,
        "cost": 12,
        "comm_capacity": 200,
        "reliability_bonus": 0,
        "description": "Radio transmitter for data relay",
    },
    {
        "name": "Onboard Computer",
        "mass": 5,
        "power_consumption": 20,
        "power_generation": 0,
        "cost": 25,
        "comm_capacity": 0,
        "reliability_bonus": 10,
        "description": "Radiation-hardened flight computer",
    },
    {
        "name": "Propulsion System",
        "mass": 80,
        "power_consumption": 40,
        "power_generation": 0,
        "cost": 35,
        "comm_capacity": 0,
        "reliability_bonus": 0,
        "description": "Chemical/ion propulsion for orbit maneuvers",
    },
    {
        "name": "Thermal Control System",
        "mass": 25,
        "power_consumption": 15,
        "power_generation": 0,
        "cost": 18,
        "comm_capacity": 0,
        "reliability_bonus": 15,
        "description": "Heaters and radiators for temperature regulation",
    },
    {
        "name": "Navigation System",
        "mass": 8,
        "power_consumption": 10,
        "power_generation": 0,
        "cost": 22,
        "comm_capacity": 0,
        "reliability_bonus": 5,
        "description": "Star trackers and gyroscopes for orientation",
    },
]

# ---------------------------------------------------------------------------
# Scientific Instruments
# ---------------------------------------------------------------------------
INSTRUMENTS: list[dict[str, Any]] = [
    {
        "name": "High Resolution Camera",
        "mass": 12,
        "power_consumption": 25,
        "cost": 30,
        "sci_value": 15,
        "data_rate": 100,
        "description": "Captures detailed surface imagery",
    },
    {
        "name": "Infrared Spectrometer",
        "mass": 8,
        "power_consumption": 20,
        "cost": 25,
        "sci_value": 12,
        "data_rate": 80,
        "description": "Analyzes mineral composition via infrared",
    },
    {
        "name": "Radar Sensor",
        "mass": 18,
        "power_consumption": 35,
        "cost": 40,
        "sci_value": 18,
        "data_rate": 150,
        "description": "Penetrates clouds and surfaces for mapping",
    },
    {
        "name": "Magnetometer",
        "mass": 3,
        "power_consumption": 5,
        "cost": 10,
        "sci_value": 8,
        "data_rate": 20,
        "description": "Measures magnetic field strength and direction",
    },
    {
        "name": "Thermal Sensor",
        "mass": 4,
        "power_consumption": 8,
        "cost": 8,
        "sci_value": 7,
        "data_rate": 30,
        "description": "Detects heat signatures and temperature variations",
    },
    {
        "name": "Atmospheric Analyzer",
        "mass": 10,
        "power_consumption": 15,
        "cost": 20,
        "sci_value": 14,
        "data_rate": 60,
        "description": "Studies atmospheric composition and pressure",
    },
    {
        "name": "Radiation Detector",
        "mass": 5,
        "power_consumption": 10,
        "cost": 12,
        "sci_value": 10,
        "data_rate": 40,
        "description": "Monitors radiation levels in space environment",
    },
]

# ---------------------------------------------------------------------------
# Launch Vehicles
# ---------------------------------------------------------------------------
LAUNCH_VEHICLES: list[dict[str, Any]] = [
    {
        "name": "Light Launcher",
        "payload_capacity": 500,
        "cost": 50,
        "compatible_orbits": ["LEO", "MEO"],
        "description": "Cost-effective launcher for small satellites",
    },
    {
        "name": "Medium Launcher",
        "payload_capacity": 2000,
        "cost": 150,
        "compatible_orbits": ["LEO", "MEO", "GEO", "Lunar Orbit"],
        "description": "Versatile launcher for medium payloads",
    },
    {
        "name": "Heavy Launcher",
        "payload_capacity": 5000,
        "cost": 350,
        "compatible_orbits": [
            "LEO",
            "MEO",
            "GEO",
            "Lunar Orbit",
            "Mars Transfer Trajectory",
            "Sun-Earth Lagrange Point",
        ],
        "description": "Heavy-lift vehicle for deep space missions",
    },
]

# ---------------------------------------------------------------------------
# Orbits
# ---------------------------------------------------------------------------
ORBITS: list[dict[str, Any]] = [
    {
        "name": "LEO",
        "complexity": 1,
        "comm_factor": 1.0,
        "duration_factor": 1.0,
        "sci_bonus": 0,
        "altitude": "200-2000 km",
        "description": "Close orbit ideal for Earth observation",
    },
    {
        "name": "MEO",
        "complexity": 2,
        "comm_factor": 0.9,
        "duration_factor": 1.2,
        "sci_bonus": 5,
        "altitude": "2000-35786 km",
        "description": "Middle altitude for navigation satellites",
    },
    {
        "name": "GEO",
        "complexity": 3,
        "comm_factor": 0.8,
        "duration_factor": 1.5,
        "sci_bonus": 10,
        "altitude": "35786 km",
        "description": "Stationary orbit matching Earth rotation",
    },
    {
        "name": "Lunar Orbit",
        "complexity": 4,
        "comm_factor": 0.6,
        "duration_factor": 2.0,
        "sci_bonus": 20,
        "altitude": "~384400 km",
        "description": "Orbit around the Moon",
    },
    {
        "name": "Mars Transfer Trajectory",
        "complexity": 5,
        "comm_factor": 0.3,
        "duration_factor": 4.0,
        "sci_bonus": 35,
        "altitude": "~225M km",
        "description": "Hohmann transfer to Mars orbit",
    },
    {
        "name": "Sun-Earth Lagrange Point",
        "complexity": 4,
        "comm_factor": 0.5,
        "duration_factor": 3.0,
        "sci_bonus": 25,
        "altitude": "~1.5M km",
        "description": "Gravitational balance point for deep space observation",
    },
]

# ---------------------------------------------------------------------------
# Mission Types
# ---------------------------------------------------------------------------
MISSION_TYPES: dict[str, dict[str, Any]] = {
    "mars_exploration": {
        "name": "Mars Exploration Mission",
        "key": "mars_exploration",
        "budget": 800,
        "required_orbits": ["Mars Transfer Trajectory"],
        "required_components": ["Propulsion System"],
        "recommended_instruments": [
            "High Resolution Camera",
            "Infrared Spectrometer",
            "Atmospheric Analyzer",
        ],
        "description": "Explore the Martian surface",
        "focus": "Surface analysis and geological research",
    },
    "lunar_research": {
        "name": "Lunar Research Mission",
        "key": "lunar_research",
        "budget": 500,
        "required_orbits": ["Lunar Orbit"],
        "required_components": ["Propulsion System"],
        "recommended_instruments": [
            "High Resolution Camera",
            "Radar Sensor",
            "Magnetometer",
        ],
        "description": "Study the Moon",
        "focus": "Surface mapping and mineral research",
    },
    "earth_observation": {
        "name": "Earth Observation Mission",
        "key": "earth_observation",
        "budget": 300,
        "required_orbits": ["LEO", "MEO", "GEO"],
        "required_components": [],
        "recommended_instruments": [
            "High Resolution Camera",
            "Radar Sensor",
            "Thermal Sensor",
        ],
        "description": "Monitor Earth environment",
        "focus": "Climate, weather, and vegetation",
    },
    "deep_space": {
        "name": "Deep Space Exploration",
        "key": "deep_space",
        "budget": 1000,
        "required_orbits": ["Sun-Earth Lagrange Point", "Mars Transfer Trajectory"],
        "required_components": ["Propulsion System", "High-Gain Antenna"],
        "recommended_instruments": [
            "Infrared Spectrometer",
            "Radiation Detector",
            "Magnetometer",
        ],
        "description": "Explore distant celestial objects",
        "focus": "Scientific observation and data collection",
    },
    "asteroid_exploration": {
        "name": "Asteroid Exploration",
        "key": "asteroid_exploration",
        "budget": 600,
        "required_orbits": ["Mars Transfer Trajectory"],
        "required_components": ["Propulsion System", "Navigation System"],
        "recommended_instruments": [
            "High Resolution Camera",
            "Infrared Spectrometer",
            "Radar Sensor",
        ],
        "description": "Study an asteroid",
        "focus": "Composition and surface characteristics",
    },
}


# ---------------------------------------------------------------------------
# Lookup helpers
# ---------------------------------------------------------------------------

def get_component_by_name(name: str) -> dict[str, Any] | None:
    """Return a spacecraft component dict by its name, or None."""
    for comp in SPACECRAFT_COMPONENTS:
        if comp["name"] == name:
            return comp
    return None


def get_instrument_by_name(name: str) -> dict[str, Any] | None:
    """Return an instrument dict by its name, or None."""
    for inst in INSTRUMENTS:
        if inst["name"] == name:
            return inst
    return None


def get_launch_vehicle_by_name(name: str) -> dict[str, Any] | None:
    """Return a launch vehicle dict by its name, or None."""
    for lv in LAUNCH_VEHICLES:
        if lv["name"] == name:
            return lv
    return None


def get_orbit_by_name(name: str) -> dict[str, Any] | None:
    """Return an orbit dict by its name, or None."""
    for orb in ORBITS:
        if orb["name"] == name:
            return orb
    return None
