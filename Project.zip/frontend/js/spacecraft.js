/* ===================================================================
   ORBIT COMMAND — spacecraft.js
   Interactive 3D Spacecraft Builder with Three.js
   Renders modular 3D spacecraft components and syncs with state & gauges
   =================================================================== */

let scScene = null;
let scCamera = null;
let scRenderer = null;
let scGroup = null;
let scAnimId = null;
let isScInitialized = false;

// Component color palette and visual configurations
const SC_MATERIALS = {
    bus: new THREE.MeshStandardMaterial({
        color: 0x94a3b8,
        metalness: 0.85,
        roughness: 0.25,
        wireframe: false
    }),
    busFoil: new THREE.MeshStandardMaterial({
        color: 0xd97706, // Gold thermal MLI foil
        metalness: 0.9,
        roughness: 0.3
    }),
    solarCell: new THREE.MeshStandardMaterial({
        color: 0x0284c7, // Deep solar cell blue
        metalness: 0.4,
        roughness: 0.2,
        emissive: 0x0369a1,
        emissiveIntensity: 0.15
    }),
    solarFrame: new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        metalness: 0.7,
        roughness: 0.4
    }),
    antennaDish: new THREE.MeshStandardMaterial({
        color: 0xe2e8f0,
        metalness: 0.6,
        roughness: 0.3,
        side: THREE.DoubleSide
    }),
    thruster: new THREE.MeshStandardMaterial({
        color: 0x334155,
        metalness: 0.9,
        roughness: 0.2
    }),
    thrusterGlow: new THREE.MeshBasicMaterial({
        color: 0x00d4ff,
        transparent: true,
        opacity: 0.65
    }),
    avionics: new THREE.MeshStandardMaterial({
        color: 0x10b981,
        emissive: 0x10b981,
        emissiveIntensity: 0.3
    }),
    sensor: new THREE.MeshStandardMaterial({
        color: 0x8b5cf6,
        metalness: 0.5,
        roughness: 0.3
    }),
    cameraLens: new THREE.MeshStandardMaterial({
        color: 0x0f172a,
        roughness: 0.05,
        metalness: 0.95
    }),
    boomArm: new THREE.MeshStandardMaterial({
        color: 0x64748b,
        metalness: 0.8,
        roughness: 0.3
    })
};

/**
 * Initialize the Spacecraft Builder page and 3D preview viewport
 */
function initSpacecraftBuilder() {
    const container = document.getElementById('spacecraft-3d-preview');
    if (!container) return;

    if (!isScInitialized) {
        initThreeViewport(container);
        isScInitialized = true;
    } else {
        onResizePreview();
    }

    bindBuilderCheckboxes();
    syncCheckboxesWithState();
    updateBuilderGauges();
    buildSpacecraftModel();
}

/**
 * Set up Three.js viewport
 */
function initThreeViewport(container) {
    // Clear any previous canvas
    container.innerHTML = '';

    const width = container.clientWidth || 400;
    const height = container.clientHeight || 500;

    scScene = new THREE.Scene();
    scCamera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    scCamera.position.set(0, 2.5, 6.5);
    scCamera.lookAt(0, 0, 0);

    scRenderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    scRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    scRenderer.setSize(width, height);
    scRenderer.toneMapping = THREE.ACESFilmicToneMapping;
    scRenderer.toneMappingExposure = 1.2;
    container.appendChild(scRenderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scScene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.4);
    keyLight.position.set(5, 8, 5);
    scScene.add(keyLight);

    const cyanRimLight = new THREE.DirectionalLight(0x00d4ff, 1.0);
    cyanRimLight.position.set(-6, -2, -5);
    scScene.add(cyanRimLight);

    const purpleFillLight = new THREE.PointLight(0x8b5cf6, 1.5, 20);
    purpleFillLight.position.set(0, -4, 4);
    scScene.add(purpleFillLight);

    // Spacecraft group containing all dynamic parts
    scGroup = new THREE.Group();
    scScene.add(scGroup);

    // Simple star particles in the preview background
    const starGeo = new THREE.BufferGeometry();
    const starCount = 300;
    const starPos = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount * 3; i++) {
        starPos[i] = (Math.random() - 0.5) * 30;
    }
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    const starMat = new THREE.PointsMaterial({ color: 0x94a3b8, size: 0.05, transparent: true, opacity: 0.6 });
    const stars = new THREE.Points(starGeo, starMat);
    scScene.add(stars);

    // Animation loop
    const clock = new THREE.Clock();
    function animate() {
        scAnimId = requestAnimationFrame(animate);
        const delta = clock.getDelta();
        if (scGroup) {
            scGroup.rotation.y += delta * 0.45;
            scGroup.rotation.x = Math.sin(clock.getElapsedTime() * 0.5) * 0.08;
        }
        scRenderer.render(scScene, scCamera);
    }
    animate();

    window.addEventListener('resize', onResizePreview);
}

function onResizePreview() {
    const container = document.getElementById('spacecraft-3d-preview');
    if (!container || !scCamera || !scRenderer) return;
    const width = container.clientWidth;
    const height = container.clientHeight;
    if (width === 0 || height === 0) return;
    scCamera.aspect = width / height;
    scCamera.updateProjectionMatrix();
    scRenderer.setSize(width, height);
}

/**
 * Procedurally build/rebuild the 3D spacecraft model based on selected components & instruments
 */
function buildSpacecraftModel() {
    if (!scGroup) return;

    // Remove old meshes
    while (scGroup.children.length > 0) {
        const obj = scGroup.children[0];
        scGroup.remove(obj);
    }

    const state = window.AppState;
    const components = (state && state.spacecraft && state.spacecraft.components) || [];
    const instruments = (state && state.spacecraft && state.spacecraft.instruments) || [];

    // 1. Central Bus / Chassis
    const busGeo = new THREE.BoxGeometry(1.2, 1.4, 1.2);
    const bus = new THREE.Mesh(busGeo, SC_MATERIALS.busFoil);
    scGroup.add(bus);

    // Decorative structural ribs on the bus
    const ribGeo = new THREE.BoxGeometry(1.25, 0.1, 1.25);
    const rib1 = new THREE.Mesh(ribGeo, SC_MATERIALS.bus);
    rib1.position.y = 0.5;
    const rib2 = new THREE.Mesh(ribGeo, SC_MATERIALS.bus);
    rib2.position.y = -0.5;
    scGroup.add(rib1);
    scGroup.add(rib2);

    // 2. Solar Panels
    const hasSolar = components.some(c => c.toLowerCase().includes('solar') || c === 'solar_panels');
    if (hasSolar) {
        // Left Wing
        const wingGroupL = createSolarWing(-1);
        scGroup.add(wingGroupL);

        // Right Wing
        const wingGroupR = createSolarWing(1);
        scGroup.add(wingGroupR);
    }

    // 3. High-Gain Antenna
    const hasAntenna = components.some(c => c.toLowerCase().includes('antenna') || c === 'high_gain_antenna');
    if (hasAntenna) {
        const antennaGroup = new THREE.Group();
        antennaGroup.position.set(0, 0.9, 0);

        // Dish
        const dishGeo = new THREE.CylinderGeometry(0.7, 0.05, 0.25, 32, 1, true);
        const dish = new THREE.Mesh(dishGeo, SC_MATERIALS.antennaDish);
        dish.rotation.x = Math.PI / 4;
        dish.rotation.z = -Math.PI / 6;
        antennaGroup.add(dish);

        // Feed Horn
        const hornGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.4, 12);
        const horn = new THREE.Mesh(hornGeo, SC_MATERIALS.thruster);
        horn.position.set(0, 0.25, 0.2);
        horn.rotation.x = Math.PI / 4;
        antennaGroup.add(horn);

        scGroup.add(antennaGroup);
    }

    // 4. Communication Transmitter
    const hasTransmitter = components.some(c => c.toLowerCase().includes('transmitter') || c === 'comm_transmitter');
    if (hasTransmitter) {
        const transGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.8, 8);
        const trans = new THREE.Mesh(transGeo, SC_MATERIALS.thruster);
        trans.position.set(0.5, 0.9, -0.4);
        scGroup.add(trans);

        // Miniature signal rings
        const ringGeo = new THREE.TorusGeometry(0.1, 0.015, 8, 24);
        const ring = new THREE.Mesh(ringGeo, SC_MATERIALS.thrusterGlow);
        ring.rotation.x = Math.PI / 2;
        ring.position.set(0.5, 1.25, -0.4);
        scGroup.add(ring);
    }

    // 5. Batteries
    const hasBatteries = components.some(c => c.toLowerCase().includes('batter') || c === 'batteries');
    if (hasBatteries) {
        const batGeo = new THREE.BoxGeometry(0.3, 0.4, 0.8);
        const batL = new THREE.Mesh(batGeo, SC_MATERIALS.bus);
        batL.position.set(-0.65, 0, 0);
        const batR = new THREE.Mesh(batGeo, SC_MATERIALS.bus);
        batR.position.set(0.65, 0, 0);

        // Status indicator LEDs
        const ledGeo = new THREE.SphereGeometry(0.04, 8, 8);
        const led = new THREE.Mesh(ledGeo, SC_MATERIALS.avionics);
        led.position.set(0.81, 0.1, 0.2);
        scGroup.add(batL);
        scGroup.add(batR);
        scGroup.add(led);
    }

    // 6. Onboard Computer / Avionics
    const hasComputer = components.some(c => c.toLowerCase().includes('computer') || c === 'onboard_computer');
    if (hasComputer) {
        const compGeo = new THREE.BoxGeometry(0.4, 0.3, 0.25);
        const compMesh = new THREE.Mesh(compGeo, SC_MATERIALS.avionics);
        compMesh.position.set(0, 0.2, 0.65);
        scGroup.add(compMesh);
    }

    // 7. Propulsion System / Engine Nozzle
    const hasPropulsion = components.some(c => c.toLowerCase().includes('propulsion') || c === 'propulsion_system');
    if (hasPropulsion) {
        const engineGroup = new THREE.Group();
        engineGroup.position.set(0, -0.9, 0);

        // Bell nozzle
        const nozzleGeo = new THREE.CylinderGeometry(0.18, 0.45, 0.5, 24, 1, true);
        const nozzle = new THREE.Mesh(nozzleGeo, SC_MATERIALS.thruster);
        engineGroup.add(nozzle);

        // Glowing exhaust plume cone
        const plumeGeo = new THREE.ConeGeometry(0.35, 0.6, 16);
        const plume = new THREE.Mesh(plumeGeo, SC_MATERIALS.thrusterGlow);
        plume.position.y = -0.4;
        plume.rotation.x = Math.PI;
        engineGroup.add(plume);

        scGroup.add(engineGroup);
    }

    // 8. Thermal Control System
    const hasThermal = components.some(c => c.toLowerCase().includes('thermal') || c === 'thermal_control');
    if (hasThermal) {
        // Louvers / Radiator panel on rear
        const radGeo = new THREE.PlaneGeometry(0.9, 0.9);
        const radiator = new THREE.Mesh(radGeo, SC_MATERIALS.antennaDish);
        radiator.position.set(0, 0, -0.62);
        radiator.rotation.y = Math.PI;
        scGroup.add(radiator);
    }

    // 9. Navigation System
    const hasNav = components.some(c => c.toLowerCase().includes('navigation') || c === 'navigation_system');
    if (hasNav) {
        // Star Tracker optical tubes
        const trackerGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.25, 12);
        const tracker1 = new THREE.Mesh(trackerGeo, SC_MATERIALS.thruster);
        tracker1.position.set(-0.35, 0.75, 0.4);
        tracker1.rotation.x = -Math.PI / 6;

        const tracker2 = new THREE.Mesh(trackerGeo, SC_MATERIALS.thruster);
        tracker2.position.set(0.35, 0.75, 0.4);
        tracker2.rotation.x = -Math.PI / 6;

        scGroup.add(tracker1);
        scGroup.add(tracker2);
    }

    // 10. Instruments
    // High Resolution Camera
    const hasCamera = instruments.some(i => i.toLowerCase().includes('camera') || i === 'high_res_camera');
    if (hasCamera) {
        const camGroup = new THREE.Group();
        camGroup.position.set(0, -0.2, 0.65);

        const barrelGeo = new THREE.CylinderGeometry(0.14, 0.16, 0.45, 20);
        const barrel = new THREE.Mesh(barrelGeo, SC_MATERIALS.thruster);
        barrel.rotation.x = Math.PI / 2;
        camGroup.add(barrel);

        const lensGeo = new THREE.CircleGeometry(0.13, 20);
        const lens = new THREE.Mesh(lensGeo, SC_MATERIALS.cameraLens);
        lens.position.z = 0.23;
        camGroup.add(lens);

        scGroup.add(camGroup);
    }

    // Infrared Spectrometer / Spectrometer
    const hasSpec = instruments.some(i => i.toLowerCase().includes('spectro') || i === 'spectrometer');
    if (hasSpec) {
        const specGeo = new THREE.BoxGeometry(0.3, 0.25, 0.35);
        const specMesh = new THREE.Mesh(specGeo, SC_MATERIALS.sensor);
        specMesh.position.set(-0.4, -0.4, 0.65);
        scGroup.add(specMesh);
    }

    // Magnetometer (Long deployed boom)
    const hasMag = instruments.some(i => i.toLowerCase().includes('magneto') || i === 'magnetometer');
    if (hasMag) {
        const boomGroup = new THREE.Group();
        boomGroup.position.set(0.6, 0.5, 0);

        const rodGeo = new THREE.CylinderGeometry(0.02, 0.02, 1.8, 8);
        const rod = new THREE.Mesh(rodGeo, SC_MATERIALS.boomArm);
        rod.rotation.z = Math.PI / 3;
        rod.position.set(0.75, 0.45, 0);
        boomGroup.add(rod);

        const podGeo = new THREE.SphereGeometry(0.08, 12, 12);
        const pod = new THREE.Mesh(podGeo, SC_MATERIALS.sensor);
        pod.position.set(1.55, 0.9, 0);
        boomGroup.add(pod);

        scGroup.add(boomGroup);
    }

    // Radar Sensor
    const hasRadar = instruments.some(i => i.toLowerCase().includes('radar') || i.toLowerCase().includes('gravity') || i === 'gravity_sensor');
    if (hasRadar) {
        const radarGeo = new THREE.CylinderGeometry(0.4, 0.4, 0.05, 6);
        const radarMesh = new THREE.Mesh(radarGeo, SC_MATERIALS.antennaDish);
        radarMesh.position.set(0, -0.72, 0);
        radarMesh.rotation.x = Math.PI / 8;
        scGroup.add(radarMesh);
    }

    // Radiation Detector / Atmospheric Analyzer
    const hasRad = instruments.some(i => i.toLowerCase().includes('radiation') || i.toLowerCase().includes('atmosph') || i === 'radiation_detector');
    if (hasRad) {
        const detectorGeo = new THREE.CylinderGeometry(0.07, 0.07, 0.3, 12);
        const detMesh = new THREE.Mesh(detectorGeo, SC_MATERIALS.avionics);
        detMesh.position.set(-0.4, 0.7, -0.4);
        scGroup.add(detMesh);
    }
}

/**
 * Helper to build an articulated solar panel wing
 */
function createSolarWing(direction = 1) {
    const wing = new THREE.Group();
    const boomGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.5, 8);
    const boom = new THREE.Mesh(boomGeo, SC_MATERIALS.solarFrame);
    boom.rotation.z = Math.PI / 2;
    boom.position.x = direction * 0.85;
    wing.add(boom);

    // Two panel segments
    for (let p = 0; p < 2; p++) {
        const panelGroup = new THREE.Group();
        const frameGeo = new THREE.BoxGeometry(0.85, 1.3, 0.04);
        const frame = new THREE.Mesh(frameGeo, SC_MATERIALS.solarFrame);
        panelGroup.add(frame);

        const cellGeo = new THREE.PlaneGeometry(0.8, 1.22);
        const cellsFront = new THREE.Mesh(cellGeo, SC_MATERIALS.solarCell);
        cellsFront.position.z = 0.025;
        const cellsBack = new THREE.Mesh(cellGeo, SC_MATERIALS.solarCell);
        cellsBack.position.z = -0.025;
        cellsBack.rotation.y = Math.PI;

        panelGroup.add(cellsFront);
        panelGroup.add(cellsBack);

        panelGroup.position.x = direction * (1.55 + p * 0.95);
        wing.add(panelGroup);
    }

    return wing;
}

/**
 * Bind checkboxes in the Spacecraft Builder DOM
 */
function bindBuilderCheckboxes() {
    // Components
    const compCheckboxes = document.querySelectorAll('.component-checkbox');
    compCheckboxes.forEach(cb => {
        // Clone to remove duplicate event listeners
        const fresh = cb.cloneNode(true);
        cb.parentNode.replaceChild(fresh, cb);

        fresh.addEventListener('change', (e) => {
            const val = e.target.value;
            const state = window.AppState;
            if (!state.spacecraft.components) state.spacecraft.components = [];

            // Find component canonical name from componentsList or map value
            const matched = state.componentsList.find(c => 
                c.name.toLowerCase().replace(/[\s-]/g, '_') === val.toLowerCase() ||
                c.name.toLowerCase().includes(val.toLowerCase().replace('_', ' ')) ||
                c.name === val
            );
            const canonicalName = matched ? matched.name : val;

            if (e.target.checked) {
                if (!state.spacecraft.components.includes(canonicalName)) {
                    state.spacecraft.components.push(canonicalName);
                }
            } else {
                state.spacecraft.components = state.spacecraft.components.filter(c => c !== canonicalName && c !== val);
            }

            // Sync visual item card styling
            const item = e.target.closest('.builder-item');
            if (item) item.classList.toggle('active', e.target.checked);

            if (typeof window.recalculateResources === 'function') {
                window.recalculateResources();
            }
            updateBuilderGauges();
            buildSpacecraftModel();
        });
    });

    // Instruments
    const instCheckboxes = document.querySelectorAll('.instrument-checkbox');
    instCheckboxes.forEach(cb => {
        const fresh = cb.cloneNode(true);
        cb.parentNode.replaceChild(fresh, cb);

        fresh.addEventListener('change', (e) => {
            const val = e.target.value;
            const state = window.AppState;
            if (!state.spacecraft.instruments) state.spacecraft.instruments = [];

            const matched = state.instrumentsList.find(i => 
                i.name.toLowerCase().replace(/[\s-]/g, '_') === val.toLowerCase() ||
                i.name.toLowerCase().includes(val.toLowerCase().replace('_', ' ')) ||
                i.name === val
            );
            const canonicalName = matched ? matched.name : val;

            if (e.target.checked) {
                if (!state.spacecraft.instruments.includes(canonicalName)) {
                    state.spacecraft.instruments.push(canonicalName);
                }
            } else {
                state.spacecraft.instruments = state.spacecraft.instruments.filter(i => i !== canonicalName && i !== val);
            }

            const item = e.target.closest('.builder-item');
            if (item) item.classList.toggle('active', e.target.checked);

            if (typeof window.recalculateResources === 'function') {
                window.recalculateResources();
            }
            updateBuilderGauges();
            buildSpacecraftModel();
        });
    });
}

/**
 * Synchronize DOM checkboxes with the AppState
 */
function syncCheckboxesWithState() {
    const state = window.AppState;
    if (!state || !state.spacecraft) return;

    const comps = state.spacecraft.components || [];
    const insts = state.spacecraft.instruments || [];

    document.querySelectorAll('.component-checkbox').forEach(cb => {
        const val = cb.value.toLowerCase();
        const isChecked = comps.some(c => 
            c.toLowerCase().replace(/[\s-]/g, '_') === val ||
            c.toLowerCase().includes(val.replace('_', ' '))
        );
        cb.checked = isChecked;
        const item = cb.closest('.builder-item');
        if (item) item.classList.toggle('active', isChecked);
    });

    document.querySelectorAll('.instrument-checkbox').forEach(cb => {
        const val = cb.value.toLowerCase();
        const isChecked = insts.some(i => 
            i.toLowerCase().replace(/[\s-]/g, '_') === val ||
            i.toLowerCase().includes(val.replace('_', ' '))
        );
        cb.checked = isChecked;
        const item = cb.closest('.builder-item');
        if (item) item.classList.toggle('active', isChecked);
    });
}

/**
 * Update the 4 resource gauges at the bottom of Spacecraft Builder
 */
function updateBuilderGauges() {
    const state = window.AppState;
    if (!state || !state.resources) return;

    const res = state.resources;
    const maxMass = 2000; // Reference maximum
    const maxPower = 1000;
    const maxBudget = state.missionBudget || 500;
    const maxData = 500;

    // Mass
    const massPct = Math.min(100, Math.round((res.totalMass / maxMass) * 100));
    const massFill = document.getElementById('gauge-mass');
    const massVal = document.getElementById('gauge-mass-value');
    if (massFill) massFill.style.width = `${massPct}%`;
    if (massVal) massVal.textContent = `${Math.round(res.totalMass)} / ${maxMass} kg`;

    // Power
    const powerPct = Math.min(100, Math.max(0, Math.round((res.availablePower / maxPower) * 100)));
    const powerFill = document.getElementById('gauge-power');
    const powerVal = document.getElementById('gauge-power-value');
    if (powerFill) {
        powerFill.style.width = `${powerPct}%`;
        powerFill.style.background = res.availablePower < 0 ? 'var(--danger)' : 'linear-gradient(90deg, #10b981, #34d399)';
    }
    if (powerVal) powerVal.textContent = `${Math.round(res.availablePower)} W net`;

    // Budget
    const costPct = Math.min(100, Math.round((res.totalCost / maxBudget) * 100));
    const budgetFill = document.getElementById('gauge-budget');
    const budgetVal = document.getElementById('gauge-budget-value');
    if (budgetFill) {
        budgetFill.style.width = `${costPct}%`;
        budgetFill.style.background = res.totalCost > maxBudget ? 'var(--danger)' : 'linear-gradient(90deg, #f59e0b, #fbbf24)';
    }
    if (budgetVal) budgetVal.textContent = `$${Math.round(res.totalCost)}M / $${Math.round(maxBudget)}M`;

    // Data Rate
    const dataPct = Math.min(100, Math.round((res.dataRate / maxData) * 100));
    const dataFill = document.getElementById('gauge-data');
    const dataVal = document.getElementById('gauge-data-value');
    if (dataFill) dataFill.style.width = `${dataPct}%`;
    if (dataVal) dataVal.textContent = `${Math.round(res.dataRate)} Mbps`;
}

// Window exports
window.initSpacecraftBuilder = initSpacecraftBuilder;
window.buildSpacecraftModel = buildSpacecraftModel;
window.updateBuilderGauges = updateBuilderGauges;
