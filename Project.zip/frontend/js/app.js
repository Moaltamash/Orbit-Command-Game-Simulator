/* ============================================================
 *  ORBIT COMMAND — app.js  (Main Application Controller)
 *  Single-Page Application core: state, navigation, API,
 *  Three.js hero scene, utilities, event wiring.
 * ============================================================ */

// ─── Global Application State ──────────────────────────────
const AppState = {
    currentPage: 'landing-page',
    selectedMission: null,
    spacecraft: {
        components: [],
        instruments: [],
    },
    launchVehicle: null,
    orbit: null,
    team: { commander: '', engineer: '', scientist: '', comms_officer: '' },
    resources: {
        totalMass: 0,
        availablePower: 0,
        totalCost: 0,
        dataRate: 0,
        commCapacity: 0,
    },
    missionBudget: 0,
    simulationResults: null,
    savedMissions: [],
    // Reference data loaded from API
    componentsList: [],
    instrumentsList: [],
    launchVehicles: [],
    orbits: [],
    missionTypes: [],
};
window.AppState = AppState;

// ─── API Communication ─────────────────────────────────────
const API_BASE = '';

async function apiGet(endpoint) {
    try {
        showLoading();
        const res = await fetch(`${API_BASE}${endpoint}`);
        if (!res.ok) throw new Error(`GET ${endpoint} failed: ${res.status}`);
        return await res.json();
    } catch (err) {
        console.error('[API GET]', err);
        showNotification(`API error: ${err.message}`, 'error');
        throw err;
    } finally {
        hideLoading();
    }
}

async function apiPost(endpoint, data) {
    try {
        showLoading();
        const res = await fetch(`${API_BASE}${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });
        if (!res.ok) throw new Error(`POST ${endpoint} failed: ${res.status}`);
        return await res.json();
    } catch (err) {
        console.error('[API POST]', err);
        showNotification(`API error: ${err.message}`, 'error');
        throw err;
    } finally {
        hideLoading();
    }
}

async function apiPut(endpoint, data) {
    try {
        showLoading();
        const res = await fetch(`${API_BASE}${endpoint}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });
        if (!res.ok) throw new Error(`PUT ${endpoint} failed: ${res.status}`);
        return await res.json();
    } catch (err) {
        console.error('[API PUT]', err);
        showNotification(`API error: ${err.message}`, 'error');
        throw err;
    } finally {
        hideLoading();
    }
}

async function apiDelete(endpoint) {
    try {
        showLoading();
        const res = await fetch(`${API_BASE}${endpoint}`, { method: 'DELETE' });
        if (!res.ok) throw new Error(`DELETE ${endpoint} failed: ${res.status}`);
        return await res.json();
    } catch (err) {
        console.error('[API DELETE]', err);
        showNotification(`API error: ${err.message}`, 'error');
        throw err;
    } finally {
        hideLoading();
    }
}

window.apiGet = apiGet;
window.apiPost = apiPost;
window.apiPut = apiPut;
window.apiDelete = apiDelete;

// ─── Utility Functions ─────────────────────────────────────

/** Toggle the loading overlay on */
function showLoading() {
    const el = document.getElementById('loading-overlay');
    if (el) el.classList.add('active');
}

/** Toggle the loading overlay off */
function hideLoading() {
    const el = document.getElementById('loading-overlay');
    if (el) el.classList.remove('active');
}

/** Show a toast notification
 *  @param {string} message
 *  @param {'success'|'error'|'warning'|'info'} type
 */
function showNotification(message, type = 'info') {
    const container = document.getElementById('notification-container') || createNotificationContainer();
    const toast = document.createElement('div');
    toast.className = `notification notification-${type}`;
    const icons = { success: '✓', error: '✗', warning: '⚠', info: 'ℹ' };
    toast.innerHTML = `
        <span class="notification-icon">${icons[type] || icons.info}</span>
        <span class="notification-message">${message}</span>
        <button class="notification-close" onclick="this.parentElement.remove()">×</button>
    `;
    container.appendChild(toast);
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        if (toast.parentElement) {
            toast.classList.add('notification-exit');
            setTimeout(() => toast.remove(), 400);
        }
    }, 5000);
}

function createNotificationContainer() {
    const c = document.createElement('div');
    c.id = 'notification-container';
    c.style.cssText = 'position:fixed;top:20px;right:20px;z-index:10000;display:flex;flex-direction:column;gap:10px;';
    document.body.appendChild(c);
    return c;
}

/** Format a number as millions budget string */
function formatCurrency(millions) {
    if (millions >= 1000) return `$${(millions / 1000).toFixed(1)}B`;
    return `$${Math.round(millions)}M`;
}

/** Format mass in kg */
function formatMass(kg) {
    if (kg >= 1000) return `${(kg / 1000).toFixed(2)} t`;
    return `${Math.round(kg)} kg`;
}

/** Format power in watts */
function formatPower(watts) {
    if (Math.abs(watts) >= 1000) return `${(watts / 1000).toFixed(1)} kW`;
    return `${Math.round(watts)} W`;
}

window.showLoading = showLoading;
window.hideLoading = hideLoading;
window.showNotification = showNotification;
window.formatCurrency = formatCurrency;
window.formatMass = formatMass;
window.formatPower = formatPower;

// ─── LocalStorage Persistence ──────────────────────────────

const STORAGE_KEY = 'orbit_command_state';

function saveStateToLocalStorage() {
    try {
        // Exclude transient / non-serialisable data
        const serialisable = {
            currentPage: AppState.currentPage,
            selectedMission: AppState.selectedMission,
            spacecraft: AppState.spacecraft,
            launchVehicle: AppState.launchVehicle,
            orbit: AppState.orbit,
            team: AppState.team,
            resources: AppState.resources,
            missionBudget: AppState.missionBudget,
            simulationResults: AppState.simulationResults,
            savedMissions: AppState.savedMissions,
        };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(serialisable));
    } catch (e) {
        console.warn('Could not save state to localStorage', e);
    }
}

function loadStateFromLocalStorage() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return;
        const saved = JSON.parse(raw);
        Object.keys(saved).forEach((key) => {
            if (key in AppState) AppState[key] = saved[key];
        });
    } catch (e) {
        console.warn('Could not load state from localStorage', e);
    }
}

window.saveStateToLocalStorage = saveStateToLocalStorage;
window.loadStateFromLocalStorage = loadStateFromLocalStorage;

// ─── Navigation ────────────────────────────────────────────

const PAGE_INIT_HOOKS = {};

/**
 * Navigate to a page section by id.
 * Hides all .page-section elements, shows the target, updates nav state.
 * @param {string} pageId  e.g. 'mission-select'
 */
function navigateTo(pageId) {
    // Hide all sections
    document.querySelectorAll('.page-section').forEach((s) => s.classList.remove('active'));

    // Show target
    const target = document.getElementById(pageId);
    if (!target) {
        console.error(`navigateTo: unknown page "${pageId}"`);
        return;
    }
    target.classList.add('active');

    // Update nav active state
    document.querySelectorAll('nav a, .nav-link').forEach((a) => {
        a.classList.remove('active');
        if (a.dataset.page === pageId || a.dataset.navigate === pageId || a.getAttribute('href') === `#${pageId}`) {
            a.classList.add('active');
        }
    });

    AppState.currentPage = pageId;
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Fire page-specific init hook
    if (PAGE_INIT_HOOKS[pageId]) {
        try { PAGE_INIT_HOOKS[pageId](); } catch (err) { console.error(`Init hook for ${pageId} failed`, err); }
    }

    saveStateToLocalStorage();
}

window.navigateTo = navigateTo;
window.PAGE_INIT_HOOKS = PAGE_INIT_HOOKS;

// ─── Three.js Hero Scene ───────────────────────────────────

let heroRenderer, heroScene, heroCamera, heroAnimId;

/**
 * Create a starfield of small dots.
 * @param {THREE.Scene} scene
 * @param {number} count
 */
function createStarfield(scene, count = 1500) {
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
        positions[i * 3]     = (Math.random() - 0.5) * 600;
        positions[i * 3 + 1] = (Math.random() - 0.5) * 600;
        positions[i * 3 + 2] = (Math.random() - 0.5) * 600;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.8, sizeAttenuation: true });
    const stars = new THREE.Points(geo, mat);
    scene.add(stars);
    return stars;
}

/**
 * Create a planet sphere.
 * @param {THREE.Scene} scene
 * @param {number} color
 * @param {number} radius
 * @returns {THREE.Mesh}
 */
function createPlanet(scene, color = 0x4488ff, radius = 5) {
    const geo = new THREE.SphereGeometry(radius, 48, 48);
    const mat = new THREE.MeshStandardMaterial({
        color,
        roughness: 0.7,
        metalness: 0.2,
        emissive: color,
        emissiveIntensity: 0.08,
    });
    const mesh = new THREE.Mesh(geo, mat);
    scene.add(mesh);
    return mesh;
}

/**
 * Generic animate loop.
 */
function animateScene(scene, camera, renderer) {
    renderer.render(scene, camera);
}

window.createStarfield = createStarfield;
window.createPlanet = createPlanet;
window.animateScene = animateScene;

/**
 * Initialise the Three.js hero scene in #hero-3d-container.
 * Rotating Earth + orbiting satellite + starfield.
 */
function init3DHeroScene() {
    const container = document.getElementById('hero-3d-container');
    if (!container || typeof THREE === 'undefined') return;

    // Prevent duplicate scenes
    if (heroRenderer) return;

    // Renderer
    heroRenderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    heroRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    heroRenderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(heroRenderer.domElement);

    // Scene
    heroScene = new THREE.Scene();

    // Camera
    heroCamera = new THREE.PerspectiveCamera(
        50,
        container.clientWidth / container.clientHeight,
        0.1,
        1000,
    );
    heroCamera.position.set(0, 3, 18);
    heroCamera.lookAt(0, 0, 0);

    // Lights
    const ambient = new THREE.AmbientLight(0x334466, 0.6);
    heroScene.add(ambient);
    const point = new THREE.PointLight(0xffffff, 1.2, 200);
    point.position.set(15, 10, 15);
    heroScene.add(point);

    // Starfield
    createStarfield(heroScene, 2000);

    // Planet (Earth-like)
    const earth = createPlanet(heroScene, 0x2266cc, 5);

    // Atmosphere glow
    const glowGeo = new THREE.SphereGeometry(5.3, 48, 48);
    const glowMat = new THREE.MeshBasicMaterial({
        color: 0x66aaff,
        transparent: true,
        opacity: 0.12,
        side: THREE.BackSide,
    });
    const glow = new THREE.Mesh(glowGeo, glowMat);
    heroScene.add(glow);

    // Orbiting satellite (small sphere)
    const satGeo = new THREE.SphereGeometry(0.2, 16, 16);
    const satMat = new THREE.MeshStandardMaterial({ color: 0xffcc00, emissive: 0xffcc00, emissiveIntensity: 0.6 });
    const satellite = new THREE.Mesh(satGeo, satMat);
    heroScene.add(satellite);

    // Orbit ring (visual guide)
    const orbitRingGeo = new THREE.RingGeometry(7.9, 8.1, 128);
    const orbitRingMat = new THREE.MeshBasicMaterial({ color: 0x4488ff, transparent: true, opacity: 0.15, side: THREE.DoubleSide });
    const orbitRing = new THREE.Mesh(orbitRingGeo, orbitRingMat);
    orbitRing.rotation.x = Math.PI / 2;
    heroScene.add(orbitRing);

    // Animation loop
    const clock = new THREE.Clock();
    function animate() {
        heroAnimId = requestAnimationFrame(animate);
        const elapsed = clock.getElapsedTime();

        // Rotate planet
        earth.rotation.y = elapsed * 0.15;
        glow.rotation.y = elapsed * 0.12;

        // Orbit satellite
        const orbitRadius = 8;
        satellite.position.x = Math.cos(elapsed * 0.6) * orbitRadius;
        satellite.position.z = Math.sin(elapsed * 0.6) * orbitRadius;
        satellite.position.y = Math.sin(elapsed * 0.4) * 1.2;

        animateScene(heroScene, heroCamera, heroRenderer);
    }
    animate();

    // Handle resize
    const onResize = () => {
        if (!container.clientWidth) return;
        heroCamera.aspect = container.clientWidth / container.clientHeight;
        heroCamera.updateProjectionMatrix();
        heroRenderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', onResize);
}

window.init3DHeroScene = init3DHeroScene;

// ─── Reference Data Loading ────────────────────────────────

async function loadReferenceData() {
    try {
        const [components, instruments, vehicles, orbits, missionTypes] = await Promise.all([
            apiGet('/api/components'),
            apiGet('/api/instruments'),
            apiGet('/api/launch-vehicles'),
            apiGet('/api/orbits'),
            apiGet('/api/mission-types'),
        ]);
        AppState.componentsList = components;
        AppState.instrumentsList = instruments;
        AppState.launchVehicles = vehicles;
        AppState.orbits = orbits;
        AppState.missionTypes = missionTypes;
        console.log('[ORBIT] Reference data loaded');
    } catch (err) {
        console.error('[ORBIT] Failed to load reference data', err);
        showNotification('Could not load reference data. Please refresh.', 'error');
    }
}

// ─── Event Binding ─────────────────────────────────────────

function bindNavLinks() {
    // Support data-navigate and data-page attributes
    document.querySelectorAll('[data-navigate], [data-page]').forEach((el) => {
        el.addEventListener('click', (e) => {
            e.preventDefault();
            const targetPage = el.dataset.navigate || el.dataset.page;
            if (targetPage) {
                navigateTo(targetPage);
            }
        });
    });
}

function bindButtons() {
    // Landing page CTA buttons
    bindClick('btn-start-mission', () => navigateTo('mission-select'));
    bindClick('btn-explore-missions', () => navigateTo('saved-missions'));

    // Back buttons and navigation buttons
    document.querySelectorAll('[data-nav-to], [data-navigate]').forEach((btn) => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const target = btn.dataset.navTo || btn.dataset.navigate;
            if (target) navigateTo(target);
        });
    });

    // Mobile menu toggle
    const toggleHandler = () => {
        const navLinks = document.querySelector('.nav-links');
        const mainNav = document.getElementById('main-nav');
        if (navLinks) navLinks.classList.toggle('open');
        if (mainNav) mainNav.classList.toggle('open');
    };
    bindClick('nav-toggle', toggleHandler);
    bindClick('menu-toggle', toggleHandler);

    // Team Mode Start Button
    bindClick('btn-start-team-mission', () => {
        window.showNotification('Crew assembled! Select your mission parameters.', 'success');
        navigateTo('mission-select');
    });
}

/** Safely bind a click handler by element id. */
function bindClick(id, handler) {
    const el = document.getElementById(id);
    if (el) el.addEventListener('click', handler);
}

window.bindClick = bindClick;

// ─── Page Init Hooks ───────────────────────────────────────

PAGE_INIT_HOOKS['landing-page'] = function () {
    init3DHeroScene();
};

PAGE_INIT_HOOKS['mission-select'] = function () {
    renderMissionTypes();
    if (typeof window.initMissionSelect === 'function') {
        window.initMissionSelect();
    }
};

PAGE_INIT_HOOKS['mission-config'] = function () {
    if (typeof window.initMissionConfig === 'function') {
        window.initMissionConfig();
    }
};

PAGE_INIT_HOOKS['resource-dashboard'] = function () {
    if (typeof window.initDashboard === 'function') {
        window.initDashboard();
    }
};

PAGE_INIT_HOOKS['saved-missions'] = function () {
    if (typeof window.initSavedMissions === 'function') {
        window.initSavedMissions();
    } else {
        loadSavedMissions();
    }
};

PAGE_INIT_HOOKS['simulation-page'] = function () {
    if (typeof window.initSimulation === 'function') {
        window.initSimulation();
    }
};

PAGE_INIT_HOOKS['evaluation-page'] = function () {
    if (typeof window.initEvaluation === 'function') {
        window.initEvaluation();
    }
};

PAGE_INIT_HOOKS['spacecraft-builder'] = function () {
    if (typeof window.initSpacecraftBuilder === 'function') {
        window.initSpacecraftBuilder();
    }
};

PAGE_INIT_HOOKS['team-mode'] = function () {
    if (typeof window.initTeamMode === 'function') {
        window.initTeamMode();
    }
};

PAGE_INIT_HOOKS['learn-section'] = function () {
    if (typeof window.initLearnSection === 'function') {
        window.initLearnSection();
    }
};

// ─── Mission Type Selection ────────────────────────────────

function renderMissionTypes() {
    const container = document.getElementById('mission-types-grid');
    if (!container) return;

    if (AppState.missionTypes.length === 0) {
        container.innerHTML = '<p class="loading-text">Loading mission types…</p>';
        return;
    }

    const icons = {
        'Earth Observation': '🌍',
        'Planetary Exploration': '🪐',
        'Deep Space Probe': '🚀',
        'Space Telescope': '🔭',
        'Communication Satellite': '📡',
        'Space Station Resupply': '🛸',
    };

    container.innerHTML = AppState.missionTypes.map((mt) => `
        <div class="mission-type-card ${AppState.selectedMission && AppState.selectedMission.name === mt.name ? 'selected' : ''}"
             data-mission="${mt.name}">
            <div class="mission-type-icon">${icons[mt.name] || '🛰️'}</div>
            <h3 class="mission-type-name">${mt.name}</h3>
            <p class="mission-type-desc">${mt.description || ''}</p>
            <div class="mission-type-meta">
                <span class="meta-budget">${formatCurrency(mt.base_budget || 0)} budget</span>
                <span class="meta-difficulty">${mt.difficulty || 'Medium'}</span>
            </div>
        </div>
    `).join('');

    // Selection handlers
    container.querySelectorAll('.mission-type-card').forEach((card) => {
        card.addEventListener('click', () => {
            const name = card.dataset.mission;
            const mission = AppState.missionTypes.find((m) => m.name === name);
            if (!mission) return;

            // Deselect others
            container.querySelectorAll('.mission-type-card').forEach((c) => c.classList.remove('selected'));
            card.classList.add('selected');

            AppState.selectedMission = mission;
            AppState.missionBudget = mission.base_budget || 500;

            // Reset spacecraft config for new mission
            AppState.spacecraft.components = [];
            AppState.spacecraft.instruments = [];
            AppState.launchVehicle = null;
            AppState.orbit = null;

            saveStateToLocalStorage();
            showNotification(`Mission selected: ${mission.name}`, 'success');

            // After short delay, navigate to config or builder
            setTimeout(() => navigateTo('spacecraft-builder'), 600);
        });
    });
}

// ─── Saved Missions ────────────────────────────────────────

async function loadSavedMissions() {
    const container = document.getElementById('saved-missions-list');
    if (!container) return;

    try {
        const missions = await apiGet('/api/missions');
        AppState.savedMissions = missions;
        renderSavedMissions(container, missions);
    } catch (err) {
        container.innerHTML = '<p class="error-text">Could not load missions.</p>';
    }
}

function renderSavedMissions(container, missions) {
    if (!missions || missions.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <span class="empty-icon">🛰️</span>
                <h3>No Missions Yet</h3>
                <p>Design your first space mission to see it here.</p>
                <button class="btn btn-primary" onclick="navigateTo('mission-select')">Start New Mission</button>
            </div>
        `;
        return;
    }

    const statusIcons = {
        completed: '✅',
        in_progress: '🔄',
        failed: '❌',
        designed: '📝',
    };

    container.innerHTML = missions.map((m) => `
        <div class="saved-mission-card" data-id="${m.id}">
            <div class="saved-mission-header">
                <span class="saved-mission-status">${statusIcons[m.status] || '📝'}</span>
                <h3 class="saved-mission-name">${m.name || 'Untitled Mission'}</h3>
            </div>
            <div class="saved-mission-meta">
                <span>Type: ${m.mission_type || 'N/A'}</span>
                <span>Score: ${m.score != null ? Math.round(m.score) : '—'}</span>
                <span>Created: ${m.created_at ? new Date(m.created_at).toLocaleDateString() : '—'}</span>
            </div>
            <div class="saved-mission-actions">
                <button class="btn btn-sm btn-outline" onclick="viewMission(${m.id})">View</button>
                <button class="btn btn-sm btn-danger" onclick="deleteMission(${m.id})">Delete</button>
            </div>
        </div>
    `).join('');
}

async function viewMission(id) {
    try {
        const mission = await apiGet(`/api/missions/${id}`);
        if (!mission) return;
        // Hydrate state from saved mission
        AppState.selectedMission = AppState.missionTypes.find((mt) => mt.name === mission.mission_type) || null;
        if (mission.spacecraft_config) {
            const cfg = typeof mission.spacecraft_config === 'string' ? JSON.parse(mission.spacecraft_config) : mission.spacecraft_config;
            AppState.spacecraft.components = cfg.components || [];
            AppState.spacecraft.instruments = cfg.instruments || [];
        }
        AppState.launchVehicle = mission.launch_vehicle || null;
        AppState.orbit = mission.orbit || null;
        if (mission.team) {
            const t = typeof mission.team === 'string' ? JSON.parse(mission.team) : mission.team;
            Object.assign(AppState.team, t);
        }
        if (mission.report) {
            AppState.simulationResults = typeof mission.report === 'string' ? JSON.parse(mission.report) : mission.report;
        }
        saveStateToLocalStorage();
        navigateTo('resource-dashboard');
    } catch (err) {
        showNotification('Failed to load mission details.', 'error');
    }
}

async function deleteMission(id) {
    if (!confirm('Delete this mission permanently?')) return;
    try {
        await apiDelete(`/api/missions/${id}`);
        showNotification('Mission deleted.', 'success');
        loadSavedMissions();
    } catch (err) {
        showNotification('Failed to delete mission.', 'error');
    }
}

window.viewMission = viewMission;
window.deleteMission = deleteMission;
window.loadSavedMissions = loadSavedMissions;
window.renderMissionTypes = renderMissionTypes;

// ─── State Change Proxy (auto-save) ────────────────────────

// Wrap state mutations through a helper so every change persists
function updateState(key, value) {
    AppState[key] = value;
    saveStateToLocalStorage();
}

function updateSpacecraft(key, value) {
    AppState.spacecraft[key] = value;
    saveStateToLocalStorage();
    // Trigger resource recalculation if dashboard is ready
    if (typeof window.recalculateResources === 'function') {
        window.recalculateResources();
    }
}

function updateResources(obj) {
    Object.assign(AppState.resources, obj);
    saveStateToLocalStorage();
}

window.updateState = updateState;
window.updateSpacecraft = updateSpacecraft;
window.updateResources = updateResources;

// ─── Bootstrap ─────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', async () => {
    console.log('[ORBIT COMMAND] Initialising…');

    // Restore previous state
    loadStateFromLocalStorage();

    // Bind navigation & buttons
    bindNavLinks();
    bindButtons();

    // Load reference data from API
    await loadReferenceData();

    // Navigate to saved page or landing
    if (AppState.currentPage && document.getElementById(AppState.currentPage)) {
        navigateTo(AppState.currentPage);
    } else {
        navigateTo('landing-page');
    }

    console.log('[ORBIT COMMAND] Ready.');
});
