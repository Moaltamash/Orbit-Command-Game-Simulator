/* ===================================================================
   ORBIT COMMAND — simulation.js
   Full Mission Simulation Engine & Evaluation Reporter
   Interactive Three.js flight trajectory, 9-phase playback,
   real-time telemetry monitors, event log, scoring, & PDF export.
   =================================================================== */

let simScene = null;
let simCamera = null;
let simRenderer = null;
let simSpacecraft = null;
let simDestination = null;
let simAnimId = null;
let simClock = null;

let currentPhaseIdx = 0;
let phaseInterval = null;
let telemetryInterval = null;
let simStartTime = null;

const SIMULATION_PHASES = [
    { key: 'preparation', name: 'Mission Preparation', icon: '📋' },
    { key: 'launch', name: 'Launch Sequence', icon: '🚀' },
    { key: 'orbit_insertion', name: 'Orbit Insertion', icon: '🛰️' },
    { key: 'deployment', name: 'Spacecraft Deployment', icon: '📡' },
    { key: 'navigation', name: 'Navigation and Travel', icon: '🧭' },
    { key: 'science_ops', name: 'Scientific Operations', icon: '🔬' },
    { key: 'data_collection', name: 'Data Collection', icon: '📊' },
    { key: 'communication', name: 'Communication with Earth', icon: '📶' },
    { key: 'completion', name: 'Mission Completion', icon: '🏁' },
];

/**
 * Initialize simulation page
 */
function initSimulation() {
    const container = document.getElementById('simulation-3d-viewport');
    if (!container) return;

    // Reset UI elements
    resetSimulationUI();

    // Setup 3D flight viewport
    initSimulation3D(container);

    // Call backend API and execute playback
    executeSimulation();
}

/**
 * Reset timeline, live stats, and event log
 */
function resetSimulationUI() {
    currentPhaseIdx = 0;
    if (phaseInterval) clearInterval(phaseInterval);
    if (telemetryInterval) clearInterval(telemetryInterval);

    // Complete button hidden
    const compWrapper = document.getElementById('sim-complete-wrapper');
    if (compWrapper) compWrapper.style.display = 'none';

    // Clear event log
    const eventLog = document.getElementById('event-log');
    if (eventLog) {
        eventLog.innerHTML = `
            <div class="event-entry event-entry--info">
                <span class="event-time">T+00:00</span>
                <span class="event-text">All systems GO. Telemetry link verified.</span>
            </div>
        `;
    }

    // Reset timeline dots
    document.querySelectorAll('.timeline-phase').forEach((p, idx) => {
        p.classList.remove('active', 'completed');
        const statusEl = p.querySelector('.phase-status');
        if (statusEl) statusEl.textContent = 'Pending';
    });

    // Reset progress bar
    const fill = document.getElementById('phase-progress-fill');
    const text = document.getElementById('phase-progress-text');
    if (fill) fill.style.width = '0%';
    if (text) text.textContent = 'Phase 0 / 9';

    // Reset live badges
    const phaseEl = document.getElementById('sim-current-phase');
    if (phaseEl) phaseEl.textContent = 'Preparation';
    const elapsedEl = document.getElementById('sim-elapsed-time');
    if (elapsedEl) elapsedEl.textContent = '00:00';
}

/**
 * Setup Three.js scene for simulation
 */
function initSimulation3D(container) {
    if (simAnimId) cancelAnimationFrame(simAnimId);
    container.innerHTML = '';

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 500;

    simScene = new THREE.Scene();
    simCamera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
    simCamera.position.set(0, 8, 22);
    simCamera.lookAt(0, 0, 0);

    simRenderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    simRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    simRenderer.setSize(width, height);
    simRenderer.setClearColor(0x030712);
    container.appendChild(simRenderer.domElement);

    // Lighting
    const ambient = new THREE.AmbientLight(0x223344, 0.8);
    simScene.add(ambient);

    const sun = new THREE.DirectionalLight(0xfff5e6, 1.6);
    sun.position.set(30, 20, 20);
    simScene.add(sun);

    // Starfield
    const starGeo = new THREE.BufferGeometry();
    const starCount = 1500;
    const starPos = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount * 3; i++) {
        starPos[i] = (Math.random() - 0.5) * 400;
    }
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    const starMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.9 });
    simScene.add(new THREE.Points(starGeo, starMat));

    // Earth (Origin)
    const earthGeo = new THREE.SphereGeometry(3.5, 32, 32);
    const earthMat = new THREE.MeshStandardMaterial({
        color: 0x1d4ed8,
        roughness: 0.6,
        metalness: 0.1,
        emissive: 0x1e40af,
        emissiveIntensity: 0.15
    });
    const earth = new THREE.Mesh(earthGeo, earthMat);
    earth.position.set(-14, -2, -8);
    simScene.add(earth);

    // Destination Planet / Body based on mission
    const mission = window.AppState?.selectedMission;
    let destColor = 0xb91c1c; // Default Mars reddish
    let destRadius = 2.4;

    if (mission) {
        const id = (mission.id || mission.key || '').toLowerCase();
        if (id.includes('lunar')) {
            destColor = 0x94a3b8; // Moon grey
            destRadius = 1.8;
        } else if (id.includes('earth')) {
            destColor = 0x059669; // Green/Blue Earth
            destRadius = 3.0;
        } else if (id.includes('asteroid')) {
            destColor = 0x78716c; // Rocky
            destRadius = 1.2;
        } else if (id.includes('deep')) {
            destColor = 0x6366f1; // Deep space nebula/gas giant
            destRadius = 3.2;
        }
    }

    const destGeo = new THREE.SphereGeometry(destRadius, 32, 32);
    const destMat = new THREE.MeshStandardMaterial({
        color: destColor,
        roughness: 0.7,
        emissive: destColor,
        emissiveIntensity: 0.1
    });
    simDestination = new THREE.Mesh(destGeo, destMat);
    simDestination.position.set(14, 2, -10);
    simScene.add(simDestination);

    // Trajectory Path Curve
    const curve = new THREE.QuadraticBezierCurve3(
        new THREE.Vector3(-14, -2, -8),
        new THREE.Vector3(0, 8, 4),
        new THREE.Vector3(14, 2, -10)
    );
    const pathPoints = curve.getPoints(50);
    const pathGeo = new THREE.BufferGeometry().setFromPoints(pathPoints);
    const pathMat = new THREE.LineDashedMaterial({
        color: 0x00d4ff,
        dashSize: 0.6,
        gapSize: 0.4,
        opacity: 0.5,
        transparent: true
    });
    const pathLine = new THREE.Line(pathGeo, pathMat);
    pathLine.computeLineDistances();
    simScene.add(pathLine);

    // Spacecraft Model (simplified satellite bus with solar panels)
    simSpacecraft = new THREE.Group();
    const busMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.8, 0.8, 0.8),
        new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.8 })
    );
    simSpacecraft.add(busMesh);

    const wingMeshL = new THREE.Mesh(
        new THREE.BoxGeometry(1.4, 0.5, 0.04),
        new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.5 })
    );
    wingMeshL.position.x = -1.1;
    simSpacecraft.add(wingMeshL);

    const wingMeshR = new THREE.Mesh(
        new THREE.BoxGeometry(1.4, 0.5, 0.04),
        new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.5 })
    );
    wingMeshR.position.x = 1.1;
    simSpacecraft.add(wingMeshR);

    simSpacecraft.position.copy(pathPoints[0]);
    simScene.add(simSpacecraft);

    simClock = new THREE.Clock();

    function renderLoop() {
        simAnimId = requestAnimationFrame(renderLoop);
        const t = simClock.getElapsedTime();

        // Rotate celestial bodies
        earth.rotation.y += 0.003;
        if (simDestination) simDestination.rotation.y += 0.004;

        // Smoothly interpolate spacecraft along trajectory according to current phase
        const progress = Math.min(1.0, currentPhaseIdx / (SIMULATION_PHASES.length - 1));
        const targetPos = curve.getPoint(progress);
        simSpacecraft.position.lerp(targetPos, 0.05);
        simSpacecraft.rotation.y += 0.015;
        simSpacecraft.rotation.z = Math.sin(t * 1.5) * 0.1;

        // Dynamic camera tracking
        simCamera.position.x = Math.sin(t * 0.1) * 3;
        simCamera.lookAt(simSpacecraft.position);

        simRenderer.render(simScene, simCamera);
    }
    renderLoop();

    // Start canvas monitors
    startCanvasMonitors();
}

/**
 * Execute backend simulation call and trigger phase progression
 */
async function executeSimulation() {
    const state = window.AppState;
    if (!state.selectedMission) {
        window.showNotification('Please select a mission first.', 'warning');
        window.navigateTo('mission-select');
        return;
    }

    const payload = {
        mission_name: `${state.selectedMission.name || 'Orbital Mission'}`,
        mission_type: state.selectedMission.id || state.selectedMission.key || 'earth_observation',
        components: state.spacecraft.components || [],
        instruments: state.spacecraft.instruments || [],
        launch_vehicle: state.launchVehicle || 'Medium Launcher',
        orbit: state.orbit || 'LEO',
        team: {
            commander: state.team.commander || 'Cmdr. Shepard',
            engineer: state.team.engineer || 'Eng. Scott',
            scientist: state.team.scientist || 'Dr. Stone',
            comms_officer: state.team.comms_officer || 'Lt. Uhura'
        }
    };

    let simResponse;
    try {
        simResponse = await window.apiPost('/api/simulate', payload);
        state.simulationResults = simResponse;
    } catch (err) {
        console.warn('Simulation API failed, running local fallback simulation', err);
        simResponse = generateFallbackSimulation(payload);
        state.simulationResults = simResponse;
    }

    // Begin animated step-by-step playback through the 9 phases
    startPhasePlayback(simResponse);
}

/**
 * Animate the 9 mission phases step-by-step
 */
function startPhasePlayback(simResponse) {
    simStartTime = Date.now();
    const phaseResults = simResponse.report?.phase_results || {};
    const events = simResponse.events || [];

    // Telemetry timer for elapsed clock
    telemetryInterval = setInterval(() => {
        const elapsedSec = Math.floor((Date.now() - simStartTime) / 1000);
        const mins = String(Math.floor(elapsedSec / 60)).padStart(2, '0');
        const secs = String(elapsedSec % 60).padStart(2, '0');
        const el = document.getElementById('sim-elapsed-time');
        if (el) el.textContent = `${mins}:${secs}`;
    }, 1000);

    // Phase transition every 2.4 seconds
    currentPhaseIdx = 0;
    advancePhase(currentPhaseIdx, phaseResults, events);

    phaseInterval = setInterval(() => {
        currentPhaseIdx++;
        if (currentPhaseIdx < SIMULATION_PHASES.length) {
            advancePhase(currentPhaseIdx, phaseResults, events);
        } else {
            clearInterval(phaseInterval);
            finishSimulation(simResponse);
        }
    }, 2500);
}

/**
 * Advance to a specific phase
 */
function advancePhase(idx, phaseResults, events) {
    const phase = SIMULATION_PHASES[idx];
    if (!phase) return;

    // Update phase indicator
    const currentPhaseEl = document.getElementById('sim-current-phase');
    if (currentPhaseEl) currentPhaseEl.textContent = phase.name;

    // Progress bar
    const progressPct = Math.round(((idx + 1) / SIMULATION_PHASES.length) * 100);
    const fill = document.getElementById('phase-progress-fill');
    const text = document.getElementById('phase-progress-text');
    if (fill) fill.style.width = `${progressPct}%`;
    if (text) text.textContent = `Phase ${idx + 1} / ${SIMULATION_PHASES.length}: ${phase.name}`;

    // Timeline dots
    document.querySelectorAll('.timeline-phase').forEach((pEl, pIdx) => {
        const statusEl = pEl.querySelector('.phase-status');
        if (pIdx < idx) {
            pEl.classList.remove('active');
            pEl.classList.add('completed');
            if (statusEl) statusEl.textContent = 'Nominal ✓';
        } else if (pIdx === idx) {
            pEl.classList.remove('completed');
            pEl.classList.add('active');
            if (statusEl) statusEl.textContent = 'In Progress...';
        } else {
            pEl.classList.remove('active', 'completed');
            if (statusEl) statusEl.textContent = 'Pending';
        }
    });

    // Update Mini Gauges dynamically
    const pwrGauge = document.getElementById('sim-gauge-power');
    const fuelGauge = document.getElementById('sim-gauge-fuel');
    const dataGauge = document.getElementById('sim-gauge-data');

    if (pwrGauge) pwrGauge.style.width = `${Math.max(20, 100 - idx * 4)}%`;
    if (fuelGauge) fuelGauge.style.width = `${Math.max(15, 100 - idx * 9)}%`;
    if (dataGauge) dataGauge.style.width = `${Math.min(100, (idx + 1) * 12)}%`;

    // Log events matching this phase
    const logContainer = document.getElementById('event-log');
    if (logContainer) {
        const elapsedSec = Math.floor((Date.now() - simStartTime) / 1000);
        const mins = String(Math.floor(elapsedSec / 60)).padStart(2, '0');
        const secs = String(elapsedSec % 60).padStart(2, '0');
        const timeStr = `T+${mins}:${secs}`;

        // Phase milestone entry
        const entry = document.createElement('div');
        entry.className = 'event-entry event-entry--info';
        entry.innerHTML = `<span class="event-time">${timeStr}</span> <span class="event-text"><strong>${phase.name}:</strong> Phase operations initiated.</span>`;
        logContainer.appendChild(entry);

        // Find any simulation events matching this phase name
        const matchedEvents = events.filter(e => 
            e.phase && (e.phase.toLowerCase().includes(phase.key) || phase.name.toLowerCase().includes(e.phase.toLowerCase()))
        );

        matchedEvents.forEach(evt => {
            const evtEl = document.createElement('div');
            let typeClass = 'event-entry--info';
            if (evt.event_type === 'warning' || evt.event_type === 'power_surge') typeClass = 'event-entry--warning';
            if (evt.event_type === 'danger' || evt.event_type === 'failure') typeClass = 'event-entry--danger';
            if (evt.event_type === 'success' || evt.event_type === 'discovery') typeClass = 'event-entry--success';

            evtEl.className = `event-entry ${typeClass}`;
            evtEl.innerHTML = `<span class="event-time">${timeStr}</span> <span class="event-text">${evt.description}</span>`;
            logContainer.appendChild(evtEl);
        });

        logContainer.scrollTop = logContainer.scrollHeight;
    }
}

/**
 * Handle simulation completion
 */
function finishSimulation(simResponse) {
    if (telemetryInterval) clearInterval(telemetryInterval);

    // Mark final phase complete
    const lastPhase = document.querySelectorAll('.timeline-phase')[SIMULATION_PHASES.length - 1];
    if (lastPhase) {
        lastPhase.classList.remove('active');
        lastPhase.classList.add('completed');
        const st = lastPhase.querySelector('.phase-status');
        if (st) st.textContent = 'Mission Complete ✓';
    }

    const logContainer = document.getElementById('event-log');
    if (logContainer) {
        const entry = document.createElement('div');
        entry.className = 'event-entry event-entry--success';
        entry.innerHTML = `<span class="event-time">FINAL</span> <span class="event-text"><strong>Simulation Complete!</strong> Telemetry archived. Final score calculated.</span>`;
        logContainer.appendChild(entry);
        logContainer.scrollTop = logContainer.scrollHeight;
    }

    // Show Complete Mission button
    const compWrapper = document.getElementById('sim-complete-wrapper');
    if (compWrapper) {
        compWrapper.style.display = 'block';
        const btn = document.getElementById('btn-complete-mission');
        if (btn) {
            btn.onclick = () => showEvaluation(simResponse);
        }
    }
}

/**
 * Continuous wave drawing on the two mini monitor canvases
 */
function startCanvasMonitors() {
    const pwrCanvas = document.getElementById('sim-power-monitor');
    const dataCanvas = document.getElementById('sim-data-monitor');
    if (!pwrCanvas || !dataCanvas) return;

    const pwrCtx = pwrCanvas.getContext('2d');
    const dataCtx = dataCanvas.getContext('2d');
    let step = 0;

    function drawMonitor() {
        if (!pwrCtx || !dataCtx) return;
        step += 0.08;

        // Power Monitor (Green wave)
        pwrCtx.fillStyle = '#060b18';
        pwrCtx.fillRect(0, 0, pwrCanvas.width, pwrCanvas.height);
        pwrCtx.strokeStyle = '#10b981';
        pwrCtx.lineWidth = 1.5;
        pwrCtx.beginPath();
        for (let x = 0; x < pwrCanvas.width; x += 3) {
            const y = (pwrCanvas.height / 2) + Math.sin(step + x * 0.05) * 18 + (Math.random() - 0.5) * 4;
            if (x === 0) pwrCtx.moveTo(x, y);
            else pwrCtx.lineTo(x, y);
        }
        pwrCtx.stroke();
        pwrCtx.fillStyle = '#10b981';
        pwrCtx.font = '10px Orbitron';
        pwrCtx.fillText('POWER BUS: 28.4V NOMINAL', 10, 16);

        // Data Monitor (Cyan Telemetry pulse)
        dataCtx.fillStyle = '#060b18';
        dataCtx.fillRect(0, 0, dataCanvas.width, dataCanvas.height);
        dataCtx.strokeStyle = '#00d4ff';
        dataCtx.lineWidth = 1.5;
        dataCtx.beginPath();
        for (let x = 0; x < dataCanvas.width; x += 3) {
            const y = (dataCanvas.height / 2) + Math.sin(step * 1.5 + x * 0.08) * 12 + ((x % 40 < 5) ? -20 : 0);
            if (x === 0) dataCtx.moveTo(x, y);
            else dataCtx.lineTo(x, y);
        }
        dataCtx.stroke();
        dataCtx.fillStyle = '#00d4ff';
        dataCtx.font = '10px Orbitron';
        dataCtx.fillText('DATA LINK: 100% CARRIER LOCK', 10, 16);

        requestAnimationFrame(drawMonitor);
    }
    requestAnimationFrame(drawMonitor);
}

/**
 * Display the Mission Evaluation Page (#evaluation-page)
 */
function showEvaluation(results) {
    if (typeof window.navigateTo === 'function') {
        window.navigateTo('evaluation-page');
    }

    const scoreData = results?.score || {};
    const totalScore = Math.round(scoreData.total || 0);
    const scoreNumEl = document.getElementById('score-number');

    // 1. Animated Score Count-up
    if (scoreNumEl) {
        let current = 0;
        const duration = 1200;
        const stepTime = 20;
        const increment = totalScore / (duration / stepTime);

        const counter = setInterval(() => {
            current += increment;
            if (current >= totalScore) {
                current = totalScore;
                clearInterval(counter);
            }
            scoreNumEl.textContent = Math.round(current);
        }, stepTime);
    }

    // 2. Achievement Badge
    const badgeEl = document.getElementById('achievement-badge');
    const badgeLevelEl = document.getElementById('badge-level');
    const levelInfo = getAchievementLevel(totalScore);

    if (badgeEl && badgeLevelEl) {
        badgeEl.className = `achievement-badge ${levelInfo.class}`;
        badgeLevelEl.textContent = levelInfo.level;
    }

    // 3. Category Breakdown Bars
    const sci = scoreData.scientific_achievement || 0;
    const res = scoreData.resource_efficiency || 0;
    const eng = scoreData.engineering_reliability || 0;
    const comm = scoreData.communication_performance || 0;
    const obj = scoreData.mission_objective_completion || 0;

    setBreakdownScore('score-science', 'bar-science', sci, 30);
    setBreakdownScore('score-resources', 'bar-resources', res, 20);
    setBreakdownScore('score-engineering', 'bar-engineering', eng, 20);
    setBreakdownScore('score-comm', 'bar-comm', comm, 15);
    setBreakdownScore('score-objective', 'bar-objective', obj, 15);

    // 4. Stats Grid
    const state = window.AppState;
    const resSummary = results?.report?.resource_summary || {};
    const finalMass = resSummary.final_mass || state.resources?.totalMass || 0;
    const remBudget = resSummary.remaining_budget || (state.missionBudget - (state.resources?.totalCost || 0));

    setText('eval-final-mass', `${Math.round(finalMass)} kg`);
    setText('eval-remaining-budget', `$${Math.round(remBudget)}M`);
    setText('eval-power-eff', `${Math.round(resSummary.power_efficiency || 92)}%`);
    setText('eval-data-transmitted', `${Math.round(resSummary.data_transmitted || 840)} MB`);
    setText('eval-phases-completed', '9 / 9');
    setText('eval-random-events', `${results?.events?.length || 3} logged`);

    // 5. Detailed Explanation & Recommendations
    const explContainer = document.getElementById('eval-explanation');
    if (explContainer) {
        const recs = results?.report?.recommendations || [];
        const isSuccess = totalScore >= 60;

        let html = `<p class="eval-summary-lead" style="font-size:1.1rem;margin-bottom:14px;color:#fff;">
            <strong>Mission Status:</strong> <span style="color:${isSuccess ? 'var(--success)' : 'var(--danger)'}">
            ${isSuccess ? 'MISSION ACCOMPLISHED' : 'MISSION UNDERPERFORMED'}</span> — ${levelInfo.level}
        </p>`;

        if (recs.length > 0) {
            html += `<ul style="list-style:disc;padding-left:20px;line-height:1.8;">`;
            recs.forEach(r => {
                html += `<li>${r}</li>`;
            });
            html += `</ul>`;
        } else {
            html += `<p>All mission objectives were verified by Mission Control. Power generation, payload mass margin, and communications throughput operated within normal flight constraints.</p>`;
        }

        explContainer.innerHTML = html;
    }

    // 6. Bind Evaluation Action Buttons
    bindEvaluationActions(results);
}

function setBreakdownScore(labelId, barId, val, max) {
    const lbl = document.getElementById(labelId);
    const bar = document.getElementById(barId);
    const rounded = Math.round(val);
    if (lbl) lbl.textContent = `${rounded} / ${max}`;
    if (bar) bar.style.width = `${Math.min(100, Math.round((rounded / max) * 100))}%`;
}

function setText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
}

function getAchievementLevel(score) {
    if (score >= 90) return { level: 'Legendary Mission', class: 'legendary' };
    if (score >= 75) return { level: 'Excellent Mission', class: 'excellent' };
    if (score >= 60) return { level: 'Successful Mission', class: 'successful' };
    if (score >= 40) return { level: 'Partial Success', class: 'partial' };
    return { level: 'Mission Failure', class: 'failure' };
}

/**
 * Bind Download PDF, Save Mission, and New Mission
 */
function bindEvaluationActions(results) {
    // Download PDF Report
    const pdfBtn = document.getElementById('btn-download-report');
    if (pdfBtn) {
        pdfBtn.onclick = () => generatePDFReport(results);
    }

    // Save Mission
    const saveBtn = document.getElementById('btn-save-mission');
    if (saveBtn) {
        saveBtn.onclick = () => saveMissionRecord(results);
    }

    // New Mission
    const newBtn = document.getElementById('btn-new-mission');
    if (newBtn) {
        newBtn.onclick = () => {
            const state = window.AppState;
            state.selectedMission = null;
            state.spacecraft = { components: [], instruments: [] };
            state.launchVehicle = null;
            state.orbit = null;
            if (typeof window.navigateTo === 'function') {
                window.navigateTo('mission-select');
            }
        };
    }
}

/**
 * Generate formal PDF Report using jsPDF
 */
async function generatePDFReport(results) {
    if (!window.jspdf || !window.jspdf.jsPDF) {
        window.showNotification('PDF generation library not loaded.', 'error');
        return;
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const state = window.AppState;
    const mission = state.selectedMission || { name: 'Space Exploration Mission' };
    const scoreData = results?.score || {};
    const totalScore = Math.round(scoreData.total || 0);
    const levelInfo = getAchievementLevel(totalScore);

    // NASA Blue Header
    doc.setFillColor(6, 11, 24);
    doc.rect(0, 0, 210, 297, 'F');

    doc.setFillColor(0, 212, 255);
    doc.rect(0, 0, 210, 8, 'F');

    doc.setTextColor(0, 212, 255);
    doc.setFontSize(22);
    doc.setFont('helvetica', 'bold');
    doc.text('ORBIT COMMAND', 14, 25);

    doc.setTextColor(255, 255, 255);
    doc.setFontSize(14);
    doc.text('OFFICIAL MISSION EVALUATION REPORT', 14, 34);

    doc.setFontSize(10);
    doc.setTextColor(148, 163, 184);
    doc.text(`Generated on: ${new Date().toUTCString()}`, 14, 42);
    doc.text('NASA Space Apps Challenge 2026 Simulation Protocol', 14, 48);

    doc.setDrawColor(0, 212, 255);
    doc.line(14, 52, 196, 52);

    // Mission Details
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('1. MISSION OVERVIEW', 14, 62);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(203, 213, 225);
    doc.text(`Mission Name:       ${mission.name}`, 14, 70);
    doc.text(`Target Orbit:       ${state.orbit || 'Low Earth Orbit (LEO)'}`, 14, 76);
    doc.text(`Launch Vehicle:     ${state.launchVehicle || 'Medium Launcher'}`, 14, 82);
    doc.text(`Payload Mass:       ${Math.round(state.resources.totalMass || 0)} kg`, 14, 88);
    doc.text(`Mission Budget:     $${state.missionBudget || 500}M`, 14, 94);

    // Flight Crew
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.text('2. FLIGHT CREW ROSTER', 14, 106);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(203, 213, 225);
    const team = state.team || {};
    doc.text(`Commander:          ${team.commander || 'Cmdr. Shepard'}`, 14, 114);
    doc.text(`Systems Engineer:   ${team.engineer || 'Eng. Scott'}`, 14, 120);
    doc.text(`Lead Scientist:     ${team.scientist || 'Dr. Stone'}`, 14, 126);
    doc.text(`Communications:     ${team.comms_officer || 'Lt. Uhura'}`, 14, 132);

    // Performance Score Box
    doc.setFillColor(15, 23, 42);
    doc.roundedRect(14, 142, 182, 45, 3, 3, 'F');
    doc.setDrawColor(0, 212, 255);
    doc.roundedRect(14, 142, 182, 45, 3, 3, 'D');

    doc.setTextColor(0, 212, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.text(`FINAL PERFORMANCE SCORE: ${totalScore} / 100`, 20, 155);

    doc.setTextColor(251, 191, 36);
    doc.setFontSize(13);
    doc.text(`Classification: ${levelInfo.level.toUpperCase()}`, 20, 164);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(203, 213, 225);
    doc.text(`Science: ${Math.round(scoreData.scientific_achievement || 0)}/30  |  Resources: ${Math.round(scoreData.resource_efficiency || 0)}/20  |  Engineering: ${Math.round(scoreData.engineering_reliability || 0)}/20  |  Comms: ${Math.round(scoreData.communication_performance || 0)}/15  |  Objectives: ${Math.round(scoreData.mission_objective_completion || 0)}/15`, 20, 175);

    // Spacecraft Hardware & Payload
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text('3. SPACECRAFT ARCHITECTURE', 14, 200);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(203, 213, 225);
    const comps = (state.spacecraft?.components || []).join(', ') || 'Standard Avionics';
    const insts = (state.spacecraft?.instruments || []).join(', ') || 'Standard Sensor Suite';
    doc.text(`Installed Components: ${comps}`, 14, 208, { maxWidth: 180 });
    doc.text(`Scientific Instruments: ${insts}`, 14, 222, { maxWidth: 180 });

    // Engineering Recommendations
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text('4. MISSION CONTROL DEBRIEF', 14, 240);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(203, 213, 225);
    const recs = results?.report?.recommendations || ['All mission operations met standard mission flight profiles.'];
    let yPos = 248;
    recs.slice(0, 3).forEach(r => {
        doc.text(`• ${r}`, 14, yPos, { maxWidth: 180 });
        yPos += 10;
    });

    // Footer
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text('ORBIT COMMAND — Built for NASA Space Apps Challenge 2026', 14, 290);

    const safeName = (mission.name || 'orbit_mission').toLowerCase().replace(/[^a-z0-9]/g, '_');
    doc.save(`${safeName}_mission_report.pdf`);
    window.showNotification('Mission PDF report downloaded!', 'success');
}

/**
 * Save mission to SQLite via backend POST /api/missions
 */
async function saveMissionRecord(results) {
    const state = window.AppState;
    const mission = state.selectedMission || {};
    const totalScore = Math.round(results?.score?.total || 0);

    const missionPayload = {
        name: `${mission.name || 'Orbital Mission'} (Design ${Math.floor(Math.random() * 900 + 100)})`,
        mission_type: mission.id || mission.key || 'earth_observation',
        components: state.spacecraft.components || [],
        instruments: state.spacecraft.instruments || [],
        launch_vehicle: state.launchVehicle || 'Medium Launcher',
        orbit: state.orbit || 'LEO',
        team: state.team || {}
    };

    try {
        const res = await window.apiPost('/api/missions', missionPayload);
        window.showNotification(`Mission "${res.name}" successfully saved to database!`, 'success');
    } catch (err) {
        console.error('Failed to save mission', err);
        window.showNotification('Could not save mission to server.', 'error');
    }
}

/**
 * Local simulation calculation fallback in case of backend network hiccup
 */
function generateFallbackSimulation(payload) {
    return {
        mission_name: payload.mission_name,
        mission_type: payload.mission_type,
        events: [
            { phase: 'Launch Sequence', event_type: 'info', description: 'Main engine ignition and liftoff confirmed.' },
            { phase: 'Spacecraft Deployment', event_type: 'success', description: 'Solar arrays deployed and sun-tracking lock established.' },
            { phase: 'Scientific Operations', event_type: 'discovery', description: 'Bonus discovery: anomalous magnetic readings detected.' }
        ],
        score: {
            scientific_achievement: 26,
            resource_efficiency: 18,
            engineering_reliability: 17,
            communication_performance: 14,
            mission_objective_completion: 15,
            total: 90,
            achievement_level: 'Legendary Mission'
        },
        report: {
            phase_results: { preparation: true, launch: true, orbit_insertion: true, deployment: true, navigation: true, science_ops: true, data_collection: true, communication: true, completion: true },
            recommendations: ['Spacecraft power margin remained optimal throughout all flight regimes.', 'Instruments collected scientific dataset in accordance with primary objectives.'],
            resource_summary: { final_mass: 420, remaining_budget: 185, power_efficiency: 94, data_transmitted: 920 }
        }
    };
}

// Window Exports
window.initSimulation = initSimulation;
window.showEvaluation = showEvaluation;
window.initEvaluation = function() {
    if (window.AppState?.simulationResults) {
        showEvaluation(window.AppState.simulationResults);
    }
};
window.generatePDFReport = generatePDFReport;
window.saveMissionRecord = saveMissionRecord;
