# ORBIT COMMAND — Space Mission Design Simulator 🛰️

![Orbit Command Banner](frontend/assets/logo.png)

> **Inspired by the NASA Space Apps Challenge 2026 — Space Mission Design Game**  
> *"DESIGN YOUR MISSION. EXPLORE THE UNKNOWN."*

---

## 🌟 Project Overview

**ORBIT COMMAND** is a fully functional, interactive, browser-based space mission design and simulation game designed for students, educators, and space enthusiasts. It provides an authentic experience of how real aerospace engineers plan, configure, resource-budget, simulate, and evaluate space missions.

Players choose mission objectives, engineer custom spacecraft with real components and scientific instruments, balance mass, power, communication throughput, and cost, select launch vehicles and orbits, simulate 9 distinct mission phases in 3D, navigate dynamic space events, and receive detailed performance debriefs with downloadable PDF reports.

---

## 🚀 Key Features

1. **5 Diverse Mission Scenarios**
   - 🔴 **Mars Exploration Mission**: Surface mapping, geology, and atmospheric analysis.
   - 🌙 **Lunar Research Mission**: Surface topography, mineral analysis, and landing prep.
   - 🌍 **Earth Observation Mission**: Climate, weather, vegetation, and ocean monitoring.
   - 🌌 **Deep Space Exploration**: Interplanetary probes, Lagrange point observations, and radiation science.
   - ☄️ **Asteroid Exploration**: Near-Earth asteroid rendezvous, composition mapping, and sample return.

2. **Interactive 3D Spacecraft Builder (Three.js)**
   - Modular 3D spacecraft bus with real-time dynamic attachments:
     - Photovoltaic Solar Panel Wings
     - Parabolic High-Gain Antenna & Communication Transmitter
     - Chemical/Ion Propulsion Engine Bell with glowing exhaust
     - Lithium-ion Battery Packs with status LEDs
     - Radiation-Hardened Onboard Avionics
     - Star Trackers & Gyroscopic Navigation
     - Scientific Instruments (Optical Telescope Camera, Infrared Spectrometer, Radar, Magnetometer Boom, Thermal & Radiation Sensors)
   - Real-time synchronization with resource gauges.

3. **Resource Management & Constraint Engine**
   - Live budgeting of **Mass (kg)**, **Net Power (W)**, **Budget ($M)**, and **Telemetry Data Rate (Mbps)**.
   - Dynamic Chart.js visualizations:
     - Mass Breakdown (Doughnut)
     - Power Balance & Storage (Bar Chart)
     - Budget Allocation (Doughnut)
   - Real-time flight constraints check: prevents underpowered systems, payload mass violations, or insufficient communication capacity.

4. **Launch Vehicles & Orbital Mechanics**
   - **Light Launcher** (500 kg payload, budget-friendly for LEO/MEO)
   - **Medium Launcher** (2,000 kg payload for LEO, MEO, GEO, Lunar)
   - **Heavy Launcher** (5,000 kg payload for deep space and Mars transfer trajectories)
   - 6 Orbit Types: LEO, SSO, GTO, MEO, HEO, Lunar Orbit, and Mars Transfer Trajectory with orbital mechanics educational explanations.

5. **9-Phase Mission Simulation Engine**
   - **Phase 1: Mission Preparation**
   - **Phase 2: Launch Sequence**
   - **Phase 3: Orbit Insertion**
   - **Phase 4: Spacecraft Deployment**
   - **Phase 5: Navigation and Travel**
   - **Phase 6: Scientific Operations**
   - **Phase 7: Data Collection**
   - **Phase 8: Communication with Earth**
   - **Phase 9: Mission Completion**
   - 3D Flight Viewport showing orbital trajectory, Earth, and destination celestial bodies.
   - Dynamic real-time telemetry canvas oscilloscopes (Power bus & Data carrier lock).
   - Random educational in-flight events (power surges, solar flares, comm delays, micrometeorite impacts, bonus scientific discoveries).

6. **Comprehensive 100-Point Scoring & Evaluation**
   - **Scientific Achievement** (30 pts)
   - **Resource Efficiency** (20 pts)
   - **Engineering Reliability** (20 pts)
   - **Communication Performance** (15 pts)
   - **Mission Objective Completion** (15 pts)
   - Achievement Tiers:
     - 🏆 **90–100**: Legendary Mission
     - 🌟 **75–89**: Excellent Mission
     - 🚀 **60–74**: Successful Mission
     - ⚠️ **40–59**: Partial Success
     - ❌ **0–39**: Mission Failure

7. **Downloadable PDF Mission Debrief (jsPDF)**
   - Generates official NASA-themed mission reports with flight crew roster, hardware manifest, score breakdown, and engineering recommendations.

8. **Team Collaboration Mode**
   - Multi-role mission workspace for up to 4 participants:
     - 🎖️ **Mission Commander**: Final go/no-go calls and objective priorities.
     - 🔧 **Systems Engineer**: Mass, power, and propulsion optimization.
     - 🔬 **Lead Scientist**: Instrument payload and scientific return.
     - 📡 **Communications Officer**: Ground station links and data telemetry.

9. **Interactive Space Academy (Educational Section)**
   - Interactive guides explaining:
     - *What is Orbital Mechanics? (Hohmann transfers, delta-v)*
     - *Understanding Spacecraft Mass (Tsiolkovsky rocket equation, dry vs wet mass)*
     - *How Solar Panels Generate Electricity in Space (Photovoltaic effect, inverse-square law)*
     - *What is Payload Capacity?*
     - *How Satellite Communication Works (Deep Space Network, radio link budgets)*
     - *Why Mission Planning Matters*

10. **Persistent Database (SQLite + SQLAlchemy)**
    - Save, load, compare, and manage past missions and design iterations.

---

## 🛠️ Technology Stack

### Frontend
- **HTML5 & CSS3**: Futuristic NASA Mission Control glassmorphism interface with custom starfield and neon glow.
- **Vanilla JavaScript (ES6+)**: Modular application architecture.
- **Three.js (r128)**: 3D solar system, procedural 3D spacecraft builder, and simulation trajectory viewport.
- **Chart.js**: Dynamic resource monitoring and budget charts.
- **jsPDF**: Client-side mission report PDF generation.

### Backend
- **Python 3.12+**
- **FastAPI**: Asynchronous high-performance REST API.
- **Uvicorn**: ASGI web server.
- **SQLite & Databases / SQLAlchemy**: Asynchronous persistent storage for mission records.
- **Pydantic v2**: Strict schema validation.

---

## 📁 Project Structure

```
orbit-command/
│
├── frontend/
│   ├── index.html          # Single Page Application structure
│   ├── css/
│   │   └── style.css       # NASA theme, glassmorphism, animations, responsive design
│   ├── js/
│   │   ├── app.js          # App lifecycle, navigation, 3D hero scene, REST API client
│   │   ├── dashboard.js    # Resource calculations, Chart.js graphs, constraint verification
│   │   ├── mission.js      # Mission select, config tabs, team mode, saved missions, educational guide
│   │   ├── spacecraft.js   # 3D procedural spacecraft builder with Three.js
│   │   └── simulation.js   # 9-phase flight simulation, 3D trajectory, telemetry, PDF report
│   └── assets/             # Icons and media
│
├── backend/
│   ├── main.py             # FastAPI REST endpoints & static file serving
│   ├── database.py         # SQLite connection & schema definitions
│   ├── models.py           # Pydantic schemas for requests and responses
│   ├── simulator.py        # Phase-by-phase simulation engine with event generation
│   ├── scoring.py          # 100-point multi-category scoring algorithm & recommendations
│   ├── data.py             # Static aerospace engineering parameters & catalogs
│   └── requirements.txt    # Python dependencies
│
└── README.md
```

---

## 💻 How to Run Locally (Windows)

### Prerequisites
- Python 3.10+ installed.

### Step 1: Open PowerShell / Terminal
Navigate to the project root:
```powershell
cd "d:\Python Project\orbit-command"
```

### Step 2: Install Backend Dependencies
```powershell
pip install -r backend/requirements.txt
```

### Step 3: Launch the Orbit Command Server
Run Uvicorn from the `backend/` directory:
```powershell
cd backend
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

### Step 4: Open in Your Browser
Open your browser and navigate to:
```
http://localhost:8000
```
FastAPI automatically serves the entire frontend application, 3D models, charts, and REST API.

---

## 📡 REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/components` | Retrieve all available spacecraft components and their physical stats |
| `GET` | `/api/instruments` | Retrieve scientific instruments catalog with power, mass, and science value |
| `GET` | `/api/launch-vehicles` | Retrieve launcher payload capacities and costs |
| `GET` | `/api/orbits` | Retrieve orbital regimes and complexities |
| `GET` | `/api/mission-types` | Retrieve mission objectives, budgets, and prerequisites |
| `POST` | `/api/simulate` | Run deterministic 9-phase flight simulation and score calculation |
| `GET` | `/api/missions` | List all saved missions from SQLite |
| `POST` | `/api/missions` | Save a new mission configuration and simulation outcome |
| `GET` | `/api/missions/{id}` | Retrieve a saved mission by ID |
| `PUT` | `/api/missions/{id}` | Update an existing mission |
| `DELETE` | `/api/missions/{id}` | Delete a mission record |
| `GET` | `/api/leaderboard` | View top mission scores |

---

## 🛰️ NASA Space Apps Challenge 2026 Attribution

This simulator was developed as an educational entry for the **NASA Space Apps Challenge 2026 — Space Mission Design Game**. It demonstrates that complex orbital mechanics, aerospace engineering trade-offs, and mission risk management can be made intuitive, visually captivating, and scientifically accurate for students around the world.
