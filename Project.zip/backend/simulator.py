"""
simulator.py — Mission simulation engine for Orbit Command.

Takes a full mission configuration and runs a phase-by-phase simulation,
generating random events that affect resources.  Uses a seeded RNG based
on the mission name hash so every run for the same name is reproducible
yet varied across different names.
"""

from __future__ import annotations

import hashlib
import random
from typing import Any

from data import (
    get_component_by_name,
    get_instrument_by_name,
    get_launch_vehicle_by_name,
    get_orbit_by_name,
    MISSION_TYPES,
)

# ── Constants ────────────────────────────────────────────────────

PHASES: list[str] = [
    "Preparation",
    "Launch",
    "Orbit Insertion",
    "Deployment",
    "Navigation",
    "Scientific Operations",
    "Data Collection",
    "Communication",
    "Completion",
]

# Event templates: (event_type, description_template, resource_impacts)
EVENT_TEMPLATES: list[dict[str, Any]] = [
    {
        "event_type": "power_surge",
        "description": "A power surge affected onboard systems.",
        "impact": {"power": -50},
    },
    {
        "event_type": "comm_delay",
        "description": "Communication delay due to solar interference.",
        "impact": {"data": -30},
    },
    {
        "event_type": "bonus_discovery",
        "description": "Instruments detected an unexpected scientific anomaly!",
        "impact": {"data": 40, "bonus_discoveries": 1},
    },
    {
        "event_type": "instrument_degradation",
        "description": "An instrument experienced minor degradation from radiation exposure.",
        "impact": {"power": -20, "data": -15},
    },
    {
        "event_type": "extended_duration",
        "description": "Mission duration extended to capture additional data.",
        "impact": {"power": -30, "data": 25, "budget": -10},
    },
    {
        "event_type": "micrometeorite_impact",
        "description": "Minor micrometeorite impact on the spacecraft hull.",
        "impact": {"power": -15, "mass_margin": -5},
    },
    {
        "event_type": "software_glitch",
        "description": "Onboard computer experienced a recoverable software glitch.",
        "impact": {"power": -10},
    },
    {
        "event_type": "solar_flare",
        "description": "Solar flare increased radiation levels near the spacecraft.",
        "impact": {"power": -40, "data": -20},
    },
    {
        "event_type": "gravity_assist",
        "description": "Successful gravity assist maneuver saved propellant!",
        "impact": {"budget": 15, "power": 10},
    },
    {
        "event_type": "calibration_success",
        "description": "Instrument calibration exceeded expectations.",
        "impact": {"data": 20},
    },
]


# ── Resource helpers ─────────────────────────────────────────────

def _compute_initial_resources(
    components: list[dict[str, Any]],
    instruments: list[dict[str, Any]],
    vehicle: dict[str, Any],
    orbit: dict[str, Any],
    mission_budget: float,
) -> dict[str, float]:
    """Compute starting resource pool from the selected configuration.

    Resources tracked:
    - power   : net available watts
    - data    : net comm/data capacity (Mbps-equivalent units)
    - budget  : remaining budget in $M after component costs
    - mass_margin : payload capacity minus total component mass (kg)
    """
    total_power_gen = sum(c.get("power_generation", 0) for c in components)
    total_power_con = (
        sum(c.get("power_consumption", 0) for c in components)
        + sum(i.get("power_consumption", 0) for i in instruments)
    )
    power = total_power_gen - total_power_con  # net watts available

    total_comm = sum(c.get("comm_capacity", 0) for c in components)
    total_data_rate = sum(i.get("data_rate", 0) for i in instruments)
    # Communication effectiveness is comm capacity × orbit comm_factor vs data
    data = (total_comm * orbit.get("comm_factor", 1.0)) - total_data_rate * 0.5

    total_cost = (
        sum(c.get("cost", 0) for c in components)
        + sum(i.get("cost", 0) for i in instruments)
        + vehicle.get("cost", 0)
    )
    budget = mission_budget - total_cost

    total_mass = (
        sum(c.get("mass", 0) for c in components)
        + sum(i.get("mass", 0) for i in instruments)
    )
    mass_margin = vehicle.get("payload_capacity", 0) - total_mass

    return {
        "power": round(power, 2),
        "data": round(data, 2),
        "budget": round(budget, 2),
        "mass_margin": round(mass_margin, 2),
        "bonus_discoveries": 0,
    }


# ── Phase success probability ───────────────────────────────────

def _phase_success_probability(
    phase: str,
    resources: dict[str, float],
    component_names: list[str],
    orbit_complexity: int,
    reliability_bonus: float,
) -> float:
    """Calculate success probability for a phase (0.0 – 1.0).

    Higher resources, lower orbit complexity, and reliability bonuses
    all improve the probability.
    """
    base = 0.75  # baseline probability

    # Resource contributions (positive resources help, negative hurt)
    if resources["power"] > 0:
        base += min(resources["power"] / 1000, 0.10)
    else:
        base -= min(abs(resources["power"]) / 500, 0.15)

    if resources["budget"] > 0:
        base += min(resources["budget"] / 500, 0.05)
    else:
        base -= min(abs(resources["budget"]) / 300, 0.10)

    if resources["mass_margin"] > 0:
        base += min(resources["mass_margin"] / 2000, 0.05)
    else:
        base -= 0.10  # over payload capacity is very bad

    # Reliability bonus from Onboard Computer, Thermal Control, Nav System
    base += reliability_bonus / 200  # e.g. 30 total → +0.15

    # Orbit complexity penalty
    base -= orbit_complexity * 0.03

    # Phase-specific modifiers
    phase_modifiers: dict[str, float] = {
        "Preparation": 0.05,
        "Launch": -0.05,
        "Orbit Insertion": -0.03,
        "Deployment": 0.0,
        "Navigation": 0.0,
        "Scientific Operations": 0.02,
        "Data Collection": 0.02,
        "Communication": 0.0,
        "Completion": 0.05,
    }
    base += phase_modifiers.get(phase, 0)

    # Component-specific boosts
    if phase == "Navigation" and "Navigation System" in component_names:
        base += 0.08
    if phase == "Launch" and "Propulsion System" in component_names:
        base += 0.06
    if phase == "Communication" and (
        "High-Gain Antenna" in component_names
        or "Communication Transmitter" in component_names
    ):
        base += 0.07

    return max(0.10, min(base, 0.99))


# ── Main simulation entry point ─────────────────────────────────

def run_simulation(
    mission_name: str,
    mission_type: str,
    component_names: list[str],
    instrument_names: list[str],
    launch_vehicle_name: str,
    orbit_name: str,
    team: dict[str, str],
) -> dict[str, Any]:
    """Run a complete phase-by-phase mission simulation.

    Returns a dict with keys:
      events        – list of SimulationEvent-like dicts
      phase_results – list of per-phase result dicts
      resources     – final resource state
      bonus_discoveries – count of bonus scientific discoveries
    """

    # ── Resolve references ───────────────────────────────────────
    components = [
        c for name in component_names
        if (c := get_component_by_name(name)) is not None
    ]
    instruments = [
        i for name in instrument_names
        if (i := get_instrument_by_name(name)) is not None
    ]
    vehicle = get_launch_vehicle_by_name(launch_vehicle_name) or {
        "name": launch_vehicle_name,
        "payload_capacity": 0,
        "cost": 0,
        "compatible_orbits": [],
    }
    orbit = get_orbit_by_name(orbit_name) or {
        "name": orbit_name,
        "complexity": 3,
        "comm_factor": 0.5,
        "duration_factor": 1.5,
        "sci_bonus": 0,
    }
    mission_def = MISSION_TYPES.get(mission_type, {})
    mission_budget = mission_def.get("budget", 500)

    # ── Seed RNG from mission name ───────────────────────────────
    seed = int(hashlib.md5(mission_name.encode()).hexdigest(), 16) % (2**31)
    rng = random.Random(seed)

    # ── Compute initial resources ────────────────────────────────
    resources = _compute_initial_resources(
        components, instruments, vehicle, orbit, mission_budget
    )

    reliability_bonus = sum(c.get("reliability_bonus", 0) for c in components)
    orbit_complexity = orbit.get("complexity", 1)

    # ── Phase-by-phase simulation ────────────────────────────────
    events: list[dict[str, Any]] = []
    phase_results: list[dict[str, Any]] = []

    for phase in PHASES:
        prob = _phase_success_probability(
            phase, resources, component_names, orbit_complexity, reliability_bonus
        )
        success = rng.random() < prob

        phase_result: dict[str, Any] = {
            "phase": phase,
            "success": success,
            "probability": round(prob, 4),
        }

        # ── Random events (30 % chance per phase) ────────────────
        if rng.random() < 0.30:
            event_template = rng.choice(EVENT_TEMPLATES)
            event = {
                "phase": phase,
                "event_type": event_template["event_type"],
                "description": event_template["description"],
                "impact": dict(event_template["impact"]),
            }
            events.append(event)

            # Apply impact to resources
            for key, delta in event_template["impact"].items():
                if key in resources:
                    resources[key] = round(resources[key] + delta, 2)

        # Additional event on phase failure
        if not success:
            failure_event = {
                "phase": phase,
                "event_type": "phase_failure",
                "description": f"Phase '{phase}' encountered a critical issue and did not fully succeed.",
                "impact": {"power": -25, "budget": -15},
            }
            events.append(failure_event)
            resources["power"] = round(resources["power"] - 25, 2)
            resources["budget"] = round(resources["budget"] - 15, 2)

        phase_result["resources_after"] = dict(resources)
        phase_results.append(phase_result)

    return {
        "events": events,
        "phase_results": phase_results,
        "resources": resources,
        "bonus_discoveries": int(resources.get("bonus_discoveries", 0)),
    }
