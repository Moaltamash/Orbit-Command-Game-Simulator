"""
database.py — SQLite database setup using the `databases` async driver
and `sqlalchemy` for table definitions.
"""

import sqlalchemy
from databases import Database

DATABASE_URL = "sqlite:///./orbit_command.db"

database = Database(DATABASE_URL)

metadata = sqlalchemy.MetaData()

# ------------------------------------------------------------------
# Missions table
# ------------------------------------------------------------------
missions = sqlalchemy.Table(
    "missions",
    metadata,
    sqlalchemy.Column("id", sqlalchemy.Integer, primary_key=True, autoincrement=True),
    sqlalchemy.Column("name", sqlalchemy.Text, nullable=False),
    sqlalchemy.Column("mission_type", sqlalchemy.Text, nullable=False),
    sqlalchemy.Column("spacecraft_config", sqlalchemy.Text, nullable=True),   # JSON
    sqlalchemy.Column("instruments", sqlalchemy.Text, nullable=True),         # JSON
    sqlalchemy.Column("launch_vehicle", sqlalchemy.Text, nullable=True),
    sqlalchemy.Column("orbit", sqlalchemy.Text, nullable=True),
    sqlalchemy.Column("team", sqlalchemy.Text, nullable=True),                # JSON
    sqlalchemy.Column("status", sqlalchemy.Text, nullable=False, default="draft"),
    sqlalchemy.Column("score", sqlalchemy.Float, nullable=True),
    sqlalchemy.Column("report", sqlalchemy.Text, nullable=True),             # JSON
    sqlalchemy.Column("created_at", sqlalchemy.Text, nullable=False),
    sqlalchemy.Column("updated_at", sqlalchemy.Text, nullable=False),
)

# ------------------------------------------------------------------
# Leaderboard table
# ------------------------------------------------------------------
leaderboard = sqlalchemy.Table(
    "leaderboard",
    metadata,
    sqlalchemy.Column("id", sqlalchemy.Integer, primary_key=True, autoincrement=True),
    sqlalchemy.Column("mission_id", sqlalchemy.Integer, nullable=False),
    sqlalchemy.Column("player_name", sqlalchemy.Text, nullable=False),
    sqlalchemy.Column("score", sqlalchemy.Float, nullable=False),
    sqlalchemy.Column("mission_type", sqlalchemy.Text, nullable=False),
    sqlalchemy.Column("created_at", sqlalchemy.Text, nullable=False),
)

# Helper to create tables synchronously on startup
engine = sqlalchemy.create_engine(
    DATABASE_URL.replace("sqlite:///", "sqlite:///"),
    connect_args={"check_same_thread": False},
)


async def connect_db() -> None:
    """Connect to the database and ensure tables exist."""
    metadata.create_all(engine)
    await database.connect()


async def disconnect_db() -> None:
    """Disconnect from the database."""
    await database.disconnect()
